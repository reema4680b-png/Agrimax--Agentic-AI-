"""
app.py — Web UI for AgriMax Pro v4 (multi-agent + RAG + split-market).

Run:
    pip install -r requirements.txt
    python app.py
Then open: http://127.0.0.1:7000/agrimax

Changes in v4:
  - URL prefix: all routes are under /agrimax
  - Agent instance is cached per session (not rebuilt every request)
  - Session TTL: old sessions expire after 2 hours (no memory leak)
  - Per-session rate limit: max 30 chat requests per hour
  - vehicle_type is passed from the sidebar form through to the agent
  - Split-market results are returned as card.mode == "split"
"""

import os
import re
import time
import uuid
from collections import defaultdict

from flask import Flask, render_template, request, jsonify, session

from agent import FarmerAdvisorAgent
import tools

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", os.urandom(32))

# ---------------------------------------------------------------------------
# In-memory session store with TTL
# Each entry: {"history": [...], "agent": FarmerAdvisorAgent, "last_seen": ts,
#              "request_times": [ts, ...]}
# ---------------------------------------------------------------------------
SESSIONS = {}
SESSION_TTL_SECONDS = 7200    # 2 hours idle → evict
RATE_LIMIT_MAX = 30           # max chat requests per session per hour
RATE_LIMIT_WINDOW = 3600      # 1 hour window

EXAMPLE_PROMPTS = [
    "I have 500kg tomatoes in Nandyal, where should I sell?",
    "What if I had 1000kg instead?",
    "Sell 250kg at Guntur Mandi and 250kg at Kurnool Market — compare both.",
    "What's the spoilage for onions after 10 days in cold storage?",
]

SUPPORTED_LANGUAGES = ["English", "Hindi", "Telugu", "Tamil", "Kannada", "Marathi", "Bengali", "Punjabi"]

_LOCATION_PATTERN = re.compile(
    r"\b(?:in|near|at)\s+([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+){0,2})\b"
)


def _evict_stale_sessions():
    now = time.time()
    stale = [sid for sid, s in SESSIONS.items() if now - s["last_seen"] > SESSION_TTL_SECONDS]
    for sid in stale:
        del SESSIONS[sid]


def _get_or_create_session(sid: str, api_key: str) -> dict:
    _evict_stale_sessions()
    if sid not in SESSIONS:
        SESSIONS[sid] = {
            "history": [],
            "agent": None,
            "api_key": None,
            "last_seen": time.time(),
            "request_times": [],
        }
    s = SESSIONS[sid]
    s["last_seen"] = time.time()
    # Rebuild agent if not yet created OR if the api_key the user is
    # submitting now differs from the one baked into the cached agent
    # (e.g. they fixed a typo'd/invalid key after the first failed attempt).
    if s["agent"] is None or s.get("api_key") != api_key:
        s["agent"] = FarmerAdvisorAgent(api_key=api_key, verbose=False)
        s["api_key"] = api_key
    return s


def _check_rate_limit(s: dict) -> bool:
    """Returns True if the request is allowed, False if rate-limited."""
    now = time.time()
    s["request_times"] = [t for t in s["request_times"] if now - t < RATE_LIMIT_WINDOW]
    if len(s["request_times"]) >= RATE_LIMIT_MAX:
        return False
    s["request_times"].append(now)
    return True


def extract_location_for_map(message: str):
    match = _LOCATION_PATTERN.search(message)
    return match.group(1).strip() if match else None


# ---------------------------------------------------------------------------
# Routes — all under /agrimax
# ---------------------------------------------------------------------------

@app.route("/agrimax")
def index():
    if "session_id" not in session:
        session["session_id"] = str(uuid.uuid4())
    sid = session["session_id"]
    existing = SESSIONS.get(sid, {})
    history = existing.get("history", [])
    return render_template(
        "index.html",
        examples=EXAMPLE_PROMPTS,
        history=history,
        crops=tools.list_supported_crops(),
        languages=SUPPORTED_LANGUAGES,
    )


@app.route("/agrimax/chat", methods=["POST"])
def chat():
    data = request.get_json()
    api_key = (data.get("api_key") or os.environ.get("GROQ_API_KEY") or "").strip()
    message = (data.get("message") or "").strip()
    language = (data.get("language") or "English").strip()
    vehicle_type = (data.get("vehicle_type") or "mini_truck").strip()

    if not api_key:
        return jsonify({"error": "Please enter your Groq API key (free at console.groq.com)."}), 400
    if not message:
        return jsonify({"error": "Please type a message."}), 400

    sid = session.get("session_id")
    if not sid:
        sid = str(uuid.uuid4())
        session["session_id"] = sid

    try:
        s = _get_or_create_session(sid, api_key)
    except Exception as e:
        return jsonify({"error": f"Agent init error: {e}"}), 500

    if not _check_rate_limit(s):
        return jsonify({"error": "Rate limit reached (30 requests/hour per session). Please wait a moment."}), 429

    history = s["history"] + [{"role": "user", "content": message}]

    # Inject vehicle_type into the message context so the agent can use it
    if vehicle_type != "mini_truck":
        history[-1]["content"] += f"\n[vehicle_type preference: {vehicle_type}]"

    try:
        result = s["agent"].run(history, language=language)
    except Exception as e:
        return jsonify({"error": f"Agent error: {e}"}), 500

    s["history"] = result["history"]

    structured = result.get("card")
    map_data = result.get("map")
    if not map_data:
        location = extract_location_for_map(message)
        if location:
            try:
                map_data = tools.find_nearby_markets(location)
            except Exception:
                map_data = None

    return jsonify({"reply": result["reply"], "card": structured, "map": map_data})


@app.route("/agrimax/reset", methods=["POST"])
def reset():
    sid = session.get("session_id")
    if sid and sid in SESSIONS:
        del SESSIONS[sid]
    return jsonify({"ok": True})


# Keep root redirect for convenience
@app.route("/")
def root_redirect():
    from flask import redirect
    return redirect("/agrimax")


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 7000))
    print(f"\n  AgriMax Pro v4 running at http://127.0.0.1:{port}/agrimax\n")
    app.run(debug=False, use_reloader=False, threaded=True, port=port)
