"""
agent.py — Multi-agent architecture for AgriMax Pro v4.

Three agents, each a separate ChatGroq reasoning loop:

  1. MarketResearchAgent  — geocode, weather, real/estimated prices.
  2. RiskAnalystAgent     — Monte Carlo / CE evaluation + RAG tip.
                           Now supports both single-best and split-market modes.
  3. FarmerAdvisorAgent (Supervisor) — farmer-facing chat. Detects when the
     farmer asks to sell across multiple specific markets and routes to the
     split-strategy path automatically.

v4 fixes:
  - Agent instance cached per session (not rebuilt on every request)
  - _run_tool_loop error recovery uses ToolMessage (not HumanMessage) so
    the Groq/LLaMA message sequence stays valid after a bad tool call
  - Market dict normalisation in tools.py guards against LLM field-name drift
  - Split-market tool added to Risk Analyst and Supervisor
"""

import json
import os
import re
from typing import Optional

from langchain_groq import ChatGroq
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, ToolMessage
from langchain_core.tools import tool

import tools

MODEL_NAME = os.environ.get("GROQ_MODEL", "openai/gpt-oss-120b")

# Matches phrasing like "...at Guntur Mandi and 250kg at Kurnool Market..."
# Used as a hard, code-level gate on split-market mode: the LLM is asked to
# only set target_markets when the farmer named 2+ specific markets, but
# models occasionally misread "the research agent found several candidate
# markets" as a split request. We don't trust the LLM's judgement alone for
# this — we require the farmer's own raw message to actually name 2+ markets
# via "at <Name>" phrasing before split mode is allowed to fire at all.
_NAMED_MARKET_PATTERN = re.compile(
    r"\bat\s+([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+){0,3})\b"
)


def _farmer_named_two_or_more_markets(message: str) -> bool:
    matches = _NAMED_MARKET_PATTERN.findall(message or "")
    distinct = {m.strip().lower() for m in matches}
    return len(distinct) >= 2


# ======================================================================
# Generic tool-calling loop runner
# ======================================================================
def _run_tool_loop(llm_with_tools, tool_map, system_prompt, user_message, max_rounds=6, verbose=False):
    """
    Single-shot tool-calling loop. Returns (final_text, captured_tool_results).
    On argument validation errors, appends a ToolMessage for every
    pending tool call so the message sequence stays valid for the LLM.
    """
    messages = [SystemMessage(content=system_prompt), HumanMessage(content=user_message)]
    captured = {}
    final_text = "Could not complete this sub-task."

    for round_num in range(max_rounds):
        try:
            ai_msg = llm_with_tools.invoke(messages)
        except Exception as e:
            # If the LLM call itself fails, inject stub ToolMessages for any
            # tool calls already appended in the previous round, then retry.
            last_ai = next((m for m in reversed(messages) if isinstance(m, AIMessage)), None)
            if last_ai and getattr(last_ai, "tool_calls", None):
                for tc in last_ai.tool_calls:
                    messages.append(ToolMessage(
                        content=json.dumps({"error": f"invocation error: {e}"}),
                        tool_call_id=tc["id"],
                    ))
            continue

        tool_calls = getattr(ai_msg, "tool_calls", None)
        if not tool_calls:
            final_text = ai_msg.content
            break

        messages.append(ai_msg)
        for tc in tool_calls:
            name = tc["name"]
            args = tc.get("args", {}) or {}
            if verbose:
                print(f"    [sub-agent] calling {name}({list(args.keys())})")
            if name in tool_map:
                try:
                    result = tool_map[name].invoke(args)
                    captured[name] = result
                except Exception as e:
                    result = {"error": str(e)}
            else:
                result = {"error": f"unknown tool {name}"}
            messages.append(ToolMessage(
                content=json.dumps(result, default=str),
                tool_call_id=tc["id"],
            ))
    return final_text, captured


# ======================================================================
# Market Research Agent
# ======================================================================
@tool
def find_nearby_markets(location: str, max_markets: int = 4) -> dict:
    """Find candidate markets near a named location, with distances in km
    and lat/lon coordinates for the map and for weather lookups."""
    return tools.find_nearby_markets(location, max_markets)


@tool
def get_weather_risk(lat: float, lon: float) -> dict:
    """Get a 7-day weather risk profile for a coordinate."""
    return tools.get_weather_risk(lat, lon)


@tool
def get_real_market_prices(crop: str, state: Optional[str] = None) -> dict:
    """Fetch real mandi prices from data.gov.in. Always try this first."""
    result = tools.get_real_market_prices(crop, state)
    return result if result is not None else {"available": False}


@tool
def get_market_prices(crop: str, markets: list) -> dict:
    """Estimated price (Rs/kg) per market. Fallback if real prices unavailable."""
    return tools.get_market_prices(crop, markets)


RESEARCH_TOOLS = [find_nearby_markets, get_weather_risk, get_real_market_prices, get_market_prices]
RESEARCH_TOOL_MAP = {t.name: t for t in RESEARCH_TOOLS}

RESEARCH_SYSTEM_PROMPT = """You are the Market Research Agent inside AgriMax Pro. Your job is to
gather facts — you do NOT recommend or run risk calculations.

Given a crop and a location:
1. Call find_nearby_markets to discover candidate markets with coordinates.
2. Call get_weather_risk for the top 1-2 nearest markets.
3. Always try get_real_market_prices first; only call get_market_prices as a
   fallback when get_real_market_prices returns {"available": false}.
4. Finish with a 2-4 sentence factual narrative: number of markets found,
   price data source (real vs estimated), and any notable weather risk.
"""


class MarketResearchAgent:
    def __init__(self, llm):
        self.llm_with_tools = llm.bind_tools(RESEARCH_TOOLS)

    def investigate(self, crop: str, location: str, verbose: bool = False) -> dict:
        user_message = f"Crop: {crop}. Location: {location}. Gather market, price, and weather facts."
        narrative, captured = _run_tool_loop(
            self.llm_with_tools, RESEARCH_TOOL_MAP, RESEARCH_SYSTEM_PROMPT, user_message, verbose=verbose
        )
        markets_data = captured.get("find_nearby_markets", {})
        real_prices = captured.get("get_real_market_prices")
        used_real_prices = bool(real_prices and real_prices.get("available", True) and real_prices.get("records"))
        return {
            "narrative": narrative,
            "markets": markets_data.get("markets", []),
            "farm_lat": markets_data.get("farm_lat"),
            "farm_lon": markets_data.get("farm_lon"),
            "location": markets_data.get("location", location),
            "geocode_source": markets_data.get("geocode_source"),
            "real_price_data": real_prices if used_real_prices else None,
            "used_real_prices": used_real_prices,
        }


# ======================================================================
# Risk Analyst Agent
# ======================================================================
@tool
def evaluate_all_strategies(
    crop: str,
    quantity_kg: float,
    markets: list,
    max_days: int = 6,
    storage_types: Optional[list] = None,
    vehicle_type: str = "mini_truck",
    risk_aversion_lambda: float = 0.6,
) -> dict:
    """Scan every (market x sell-day x storage-type) combination and return
    results ranked by certainty-equivalent revenue. Use this for single-best
    recommendations (when the farmer does NOT specify which markets to split across)."""
    return tools.evaluate_all_strategies(
        crop=crop, quantity_kg=quantity_kg, markets=markets, max_days=max_days,
        storage_types=storage_types or ["ambient"], vehicle_type=vehicle_type,
        risk_aversion_lambda=risk_aversion_lambda,
    )


@tool
def evaluate_split_strategy(
    crop: str,
    total_quantity_kg: float,
    target_markets: list,
    max_days: int = 6,
    storage_types: Optional[list] = None,
    vehicle_type: str = "mini_truck",
    risk_aversion_lambda: float = 0.6,
) -> dict:
    """Evaluate selling across MULTIPLE specific markets simultaneously.
    Use this when the farmer explicitly asks to sell at 2 or more named markets.
    target_markets: list of {name, distance_km, lat?, lon?, quantity_kg?}.
    If quantity_kg is omitted per market, the total is split evenly."""
    return tools.evaluate_split_strategy(
        crop=crop, total_quantity_kg=total_quantity_kg, target_markets=target_markets,
        max_days=max_days, storage_types=storage_types or ["ambient"],
        vehicle_type=vehicle_type, risk_aversion_lambda=risk_aversion_lambda,
    )


@tool
def estimate_spoilage_loss(crop: str, storage_days: float, storage_type: str = "ambient") -> dict:
    """Quick spot-check: fraction of produce lost to spoilage."""
    return tools.estimate_spoilage_loss(crop, storage_days, storage_type)


@tool
def search_knowledge_base(query: str, top_k: int = 2, category: Optional[str] = None) -> dict:
    """Retrieve crop-handling tips, logistics tips, or actuarial glossary entries
    from the RAG knowledge base. Always call once per analysis."""
    return tools.search_knowledge_base(query, top_k, category)


RISK_TOOLS = [evaluate_all_strategies, evaluate_split_strategy, estimate_spoilage_loss, search_knowledge_base]
RISK_TOOL_MAP = {t.name: t for t in RISK_TOOLS}

RISK_SYSTEM_PROMPT = """You are the Risk Analyst Agent inside AgriMax Pro.
You receive market facts from the Market Research Agent. Your job:

1. SPLIT MODE — if target_markets is provided (farmer asked to sell across specific markets):
   Call evaluate_split_strategy with crop, total_quantity_kg, and the target_markets list
   (pass lat/lon from the Market Research Agent's results where available).

2. SINGLE MODE — otherwise:
   Call evaluate_all_strategies with crop, quantity, and all available markets.
   The top-ranked row (best_strategy) and runner-up are the authoritative numbers —
   do NOT reorder or second-guess them.

3. Always call search_knowledge_base once for the crop to retrieve a practical tip.

4. Finish with a SHORT internal note (1-3 sentences) explaining the winning option
   and the key trade-off vs the alternative. Base this strictly on returned numbers.
"""


class RiskAnalystAgent:
    def __init__(self, llm):
        self.llm_with_tools = llm.bind_tools(RISK_TOOLS)

    def analyze(self, crop, quantity_kg, markets, max_days, risk_aversion_lambda,
                target_markets=None, verbose=False) -> dict:
        if target_markets:
            user_message = (
                f"Crop: {crop}. Total quantity: {quantity_kg} kg. Time window: up to {max_days} days. "
                f"Risk aversion lambda: {risk_aversion_lambda}. "
                f"The farmer wants to sell across these specific markets: {json.dumps(target_markets)}. "
                f"Use evaluate_split_strategy. Then retrieve one grounded tip."
            )
        else:
            user_message = (
                f"Crop: {crop}. Quantity: {quantity_kg} kg. Time window: up to {max_days} days. "
                f"Risk aversion lambda: {risk_aversion_lambda}. "
                f"Markets (with coordinates): {json.dumps(markets)}. "
                f"Run evaluate_all_strategies then retrieve one grounded tip."
            )
        narrative, captured = _run_tool_loop(
            self.llm_with_tools, RISK_TOOL_MAP, RISK_SYSTEM_PROMPT, user_message, verbose=verbose
        )
        # Prefer split result if captured, else single
        evaluation = (
            captured.get("evaluate_split_strategy")
            or captured.get("evaluate_all_strategies")
            or {}
        )
        return {
            "narrative": narrative,
            "evaluation": evaluation,
            "tip": captured.get("search_knowledge_base", {}),
        }


# ======================================================================
# Supervisor — the farmer-facing agent
# ======================================================================
SUPERVISOR_SYSTEM_PROMPT = """You are AgriMax Pro, a multi-agent actuarial decision-support system
for farmers deciding where and when to sell their crop. You are the Supervisor.

You have exactly two tools:
  - consult_market_researcher(crop, location): discovers nearby markets (with
    coordinates), weather, and price data.
  - consult_risk_analyst(crop, quantity_kg, markets, max_days,
    risk_aversion_lambda, target_markets): runs the full risk evaluation.
    Pass target_markets only when the farmer explicitly names 2 or more
    specific markets they want to sell at simultaneously.

SCOPE GUARD: if the message is not about selling crops, farming logistics, or
this system's capabilities, reply politely that you're AgriMax Pro (an
agricultural advisor) and cannot help with unrelated topics.

MISSING INFORMATION: if both crop AND location are not known, ask a friendly
clarifying question instead of calling tools. Quantity defaults to 500 kg and
time window to 5 days — state these assumptions rather than asking.

FOLLOW-UP PARAMETER CHANGES: if the farmer changes quantity, time window, risk
level, vehicle type, or asks a "what if" scenario (e.g. "what if I had 1000kg"),
you MUST re-run both consult_market_researcher AND consult_risk_analyst with the
new parameters. Never answer a parameter-change follow-up from memory alone —
the numbers will be wrong. The sub-agents are fast; always re-run them.

SPLIT-MARKET DETECTION: if the farmer asks to sell across 2 or more SPECIFIC
named markets (e.g. "sell half at Guntur and half at Kurnool"), set
target_markets in consult_risk_analyst. Do NOT set target_markets for a
general "find me the best market" query — use that only when the farmer
explicitly names the markets they want to split across.
IMPORTANT: consult_market_researcher will typically return 3-4 CANDIDATE
markets near the farmer's location even for a normal single-market query.
The mere presence of multiple candidates is NOT a split request — it just
gives the Risk Analyst options to pick the single best one from. Only treat
it as a split if the farmer's own wording named multiple specific markets.

ORCHESTRATION (once crop + location are known):
  1. Call consult_market_researcher(crop, location) first.
  2. Call consult_risk_analyst with the markets it returned, the farmer's
     quantity (default 500 kg), time window (default 5 days),
     risk_aversion_lambda (low~1.2, medium~0.6, high~0.2; default medium),
     and target_markets only if the farmer specified a split.

YOUR FINAL REPLY — For single-market results, structure your reply with these EXACT markers on separate lines, followed immediately by content (no blank line between marker and text):

[WHY MARKET] One sentence explaining why this specific market was chosen over others (price, proximity, demand).
[WHY DAY] One sentence explaining why this sell day is optimal (spoilage curve, price trend, storage cost trade-off).
[KEY TRADEOFF] One sentence on the main trade-off vs. the runner-up option.
[RAG TIP] One brief practical farming tip relevant to this crop/market/season.

For split-market results, write 3-5 warm conversational sentences instead (no markers):
  - Name the split plan and combined revenue.
  - Give one reason for the split.
  - End with "Check the dashboard for the full breakdown."

Rules for ALL replies:
  - Use "Revenue", never "Profit". Never paste JSON or field names.
  - Keep each section to 1-2 sentences. Total reply under 120 words.

For off-topic redirects, casual questions, or spot-checks, reply briefly
in the same friendly tone — no fixed format needed.

Never invent numbers outside what the sub-agents returned.
"""


def _history_to_messages(history: list):
    messages = []
    for m in history:
        if m["role"] == "user":
            messages.append(HumanMessage(content=m["content"]))
        else:
            messages.append(AIMessage(content=m["content"]))
    return messages


class FarmerAdvisorAgent:
    """
    The Supervisor. Cached per session in app.py so it's not rebuilt on
    every request (fixes the per-request reinstantiation bug).
    """

    def __init__(self, api_key: str = None, model: str = MODEL_NAME, verbose: bool = False):
        api_key = api_key or os.environ.get("GROQ_API_KEY")
        if not api_key:
            raise ValueError("No Groq API key found. Pass api_key= or set GROQ_API_KEY.")

        self.verbose = verbose
        base_llm = ChatGroq(model=model, api_key=api_key, temperature=0.2)

        self.researcher = MarketResearchAgent(base_llm)
        self.risk_analyst = RiskAnalystAgent(base_llm)
        self.last_map_data = None
        self.last_research = None
        self.last_risk_result = None
        self._current_user_message = None

        @tool
        def consult_market_researcher(crop: str, location: str) -> dict:
            """Delegate to the Market Research Agent: discovers nearby markets
            (with coordinates), weather risk, and price data. Call first."""
            result = self.researcher.investigate(crop, location, verbose=self.verbose)
            self.last_research = result
            self.last_map_data = {
                "location": result["location"],
                "farm_lat": result["farm_lat"],
                "farm_lon": result["farm_lon"],
                "markets": result["markets"],
            }
            return result

        @tool
        def consult_risk_analyst(
            crop: str,
            quantity_kg: float,
            markets: list,
            max_days: int = 5,
            risk_aversion_lambda: float = 0.6,
            target_markets: Optional[list] = None,
        ) -> dict:
            """Delegate to the Risk Analyst Agent. Pass target_markets only when
            the farmer explicitly named 2+ specific markets to split across.
            Otherwise leave it None for a standard best-single-market analysis."""
            # Hard guard: even if the LLM passes target_markets, only honor a
            # split if the farmer's own message actually names 2+ markets
            # (e.g. "...at Guntur Mandi and ...at Kurnool Market"). This stops
            # the model from treating "the research agent found 4 nearby
            # candidates" as a split request when none was made.
            if target_markets and not _farmer_named_two_or_more_markets(self._current_user_message or ""):
                target_markets = None
            result = self.risk_analyst.analyze(
                crop, quantity_kg, markets, max_days, risk_aversion_lambda,
                target_markets=target_markets, verbose=self.verbose
            )
            self.last_risk_result = result
            return result

        self.supervisor_tools = [consult_market_researcher, consult_risk_analyst]
        self.supervisor_tool_map = {t.name: t for t in self.supervisor_tools}
        self.llm_with_tools = base_llm.bind_tools(self.supervisor_tools)

    def run(self, conversation_history: list, language: str = "English", max_tool_rounds: int = 8) -> dict:
        if not conversation_history or conversation_history[-1]["role"] != "user":
            raise ValueError("conversation_history must end with the new user message.")

        latest_message = conversation_history[-1]["content"]
        prior_history = conversation_history[:-1]
        self._current_user_message = latest_message

        if language and language.lower() != "english":
            latest_message = f"{latest_message}\n\n(Please reply in {language}.)"

        messages = [SystemMessage(content=SUPERVISOR_SYSTEM_PROMPT)] + _history_to_messages(prior_history)
        messages.append(HumanMessage(content=latest_message))

        reply_text = "Sorry, I couldn't complete that analysis."
        # Save previous state — restored below if no tools fire this turn
        _prev_map = self.last_map_data
        _prev_research = self.last_research
        _prev_risk = self.last_risk_result
        self.last_map_data = None
        self.last_research = None
        self.last_risk_result = None
        _tools_fired = False
        _last_error = None

        for round_num in range(max_tool_rounds):
            try:
                ai_msg = self.llm_with_tools.invoke(messages)
            except Exception as e:
                _last_error = str(e)
                print(f"  [supervisor round {round_num + 1}] error: {e}")
                # Recover: inject ToolMessages for any pending tool calls
                last_ai = next((m for m in reversed(messages) if isinstance(m, AIMessage)), None)
                if last_ai and getattr(last_ai, "tool_calls", None):
                    for tc in last_ai.tool_calls:
                        messages.append(ToolMessage(
                            content=json.dumps({"error": f"argument error: {e}. Retry with corrected types."}),
                            tool_call_id=tc["id"],
                        ))
                else:
                    # No pending tool call to attach the error to (e.g. the very
                    # first call failed, such as a bad/decommissioned model name).
                    # Bail out immediately instead of silently retrying 8x.
                    reply_text = f"AI provider error: {_last_error}"
                    new_history = conversation_history + [{"role": "assistant", "content": reply_text}]
                    return {"reply": reply_text, "history": new_history, "map": None, "card": None}
                continue

            tool_calls = getattr(ai_msg, "tool_calls", None)
            if not tool_calls:
                reply_text = ai_msg.content
                break

            messages.append(ai_msg)
            _tools_fired = True
            for tc in tool_calls:
                name = tc["name"]
                args = tc.get("args", {}) or {}
                if self.verbose:
                    print(f"  [supervisor round {round_num + 1}] consulting {name}")
                if name in self.supervisor_tool_map:
                    try:
                        result = self.supervisor_tool_map[name].invoke(args)
                    except Exception as e:
                        result = {"error": str(e)}
                else:
                    result = {"error": f"unknown tool {name}"}
                messages.append(ToolMessage(
                    content=json.dumps(result, default=str),
                    tool_call_id=tc["id"],
                ))
        else:
            reply_text = ("I had trouble finishing that analysis — could you simplify your question "
                          "(e.g. one crop, one location)?")

        # If no tools fired this turn (LLM replied from memory on a follow-up),
        # restore previous session state so the dashboard card can still be built.
        if not _tools_fired:
            if self.last_map_data is None:
                self.last_map_data = _prev_map
            if self.last_research is None:
                self.last_research = _prev_research
            if self.last_risk_result is None:
                self.last_risk_result = _prev_risk

        # Build dashboard card deterministically from structured tool output
        card = None
        if self.last_risk_result and self.last_risk_result.get("evaluation"):
            evaluation = self.last_risk_result["evaluation"]
            has_split = evaluation.get("mode") == "split" and evaluation.get("legs")
            has_single = evaluation.get("best_strategy")

            if has_split or has_single:
                used_real_prices = bool(self.last_research and self.last_research.get("used_real_prices"))
                geocode_source = (self.last_research or {}).get("geocode_source") or ""
                price_note = (
                    "data.gov.in (real, live mandi data)" if used_real_prices
                    else "estimated model (no live mandi match for this crop/region)"
                )
                geo_note = (
                    "OpenStreetMap (real)" if geocode_source and "mock" not in geocode_source
                    else "estimated (location not found / offline)"
                )
                data_sources = f"Market locations: {geo_note}. Weather: Open-Meteo (real). Prices: {price_note}."

                card = tools.build_recommendation_card(
                    evaluation,
                    why=reply_text,
                    tip=self.last_risk_result.get("tip"),
                    agents_consulted="Market Research Agent, Risk Analyst Agent",
                    data_sources=data_sources,
                )
                if card:
                    card["used_real_prices"] = used_real_prices

        new_history = conversation_history + [{"role": "assistant", "content": reply_text}]
        return {"reply": reply_text, "history": new_history, "map": self.last_map_data, "card": card}
