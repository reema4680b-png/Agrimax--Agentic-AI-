// ============================================================
// AgriMax Pro v5 — app.js
// Features: Agent Workflow Viz, Risk Meter, Confidence Score,
//   Suggestion Chips, Monte Carlo Summary, Decision Comparison Table,
//   Top-3 Strategy Cards, Market Ranking Table, Structured Why,
//   RAG Citation Panel, Day-by-Day Sparkline, Weather Impact Panel,
//   Price Trend Arrows, Break-Even Calculator, Profit Waterfall,
//   Perishability Badge, Data Source Badge, Live Status Banner,
//   Audit Trail, Assumption Box, Mobile Sidebar Toggle,
//   Language Auto-Detect, Spoilage Countdown, Print/Export
// ============================================================

// ---------- Tab switching ----------
document.querySelectorAll(".tab-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById("tab-" + btn.dataset.tab).classList.add("active");
  });
});

function switchToTab(name) {
  document.querySelector(`.tab-btn[data-tab="${name}"]`).click();
}

// ---------- Mobile sidebar toggle ----------
const sidebarEl = document.querySelector(".sidebar");
const toggleBtn = document.getElementById("sidebar-toggle");
if (toggleBtn) {
  toggleBtn.addEventListener("click", () => {
    sidebarEl.classList.toggle("sidebar-open");
  });
}

// ---------- Language auto-detect ----------
(function autoDetectLanguage() {
  const langSel = document.getElementById("language");
  if (!langSel) return;
  const nav = (navigator.language || "").toLowerCase();
  const map = { kn: "Kannada", hi: "Hindi", te: "Telugu", ta: "Tamil" };
  for (const [code, name] of Object.entries(map)) {
    if (nav.startsWith(code)) {
      for (const opt of langSel.options) {
        if (opt.value === name) { langSel.value = name; break; }
      }
      break;
    }
  }
})();

// ---------- Shared helpers ----------
function fmtMoney(value) {
  if (!value) return "—";
  const match = value.match(/-?[\d.]+/);
  if (!match) return value;
  const num = parseFloat(match[0]);
  if (isNaN(num)) return value;
  const formatted = num.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return value.toLowerCase().startsWith("rs") ? "₹" + formatted : formatted;
}

function fmtRupeeNumber(numStr) {
  const num = parseFloat((numStr || "").replace(/,/g, ""));
  if (isNaN(num)) return numStr || "—";
  return "₹" + num.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function getRiskBadgeClass(label) {
  if (!label) return "";
  const l = label.toLowerCase();
  if (l.includes("high")) return "badge-high";
  if (l.includes("medium")) return "badge-medium";
  return "badge-low";
}

function trendArrow(pct) {
  if (!pct && pct !== 0) return "";
  if (pct > 0.5) return `<span class="trend-up">↑ ${pct}%/day</span>`;
  if (pct < -0.5) return `<span class="trend-down">↓ ${Math.abs(pct)}%/day</span>`;
  return `<span class="trend-flat">→ stable</span>`;
}

// ---------- Parse structured WHY from supervisor ----------
function parseWhySections(why) {
  if (!why) return null;
  const sections = {
    market: null, day: null, tradeoff: null, rag: null, fallback: why
  };
  const markers = [
    { key: "market", tag: "[WHY MARKET]" },
    { key: "day",    tag: "[WHY DAY]" },
    { key: "tradeoff", tag: "[KEY TRADEOFF]" },
    { key: "rag",   tag: "[RAG TIP]" },
  ];
  let found = false;
  for (const { key, tag } of markers) {
    const idx = why.indexOf(tag);
    if (idx !== -1) {
      found = true;
      const afterTag = why.slice(idx + tag.length).trim();
      // grab until the next marker or end
      const nextIdx = markers
        .filter(m => m.key !== key)
        .map(m => why.indexOf(m.tag, idx + tag.length))
        .filter(i => i > idx)
        .reduce((a, b) => (b !== -1 && (a === -1 || b < a) ? b : a), -1);
      sections[key] = (nextIdx === -1 ? afterTag : afterTag.slice(0, nextIdx - idx - tag.length)).trim();
    }
  }
  return found ? sections : null;
}

function renderStructuredWhy(why) {
  const s = parseWhySections(why);
  if (!s) return `<p class="report-why">${why}</p>`;
  return `
    <div class="why-structured">
      ${s.market ? `<div class="why-section"><span class="why-label">📍 Why this market</span><span class="why-text">${s.market}</span></div>` : ""}
      ${s.day    ? `<div class="why-section"><span class="why-label">📅 Why this day</span><span class="why-text">${s.day}</span></div>` : ""}
      ${s.tradeoff ? `<div class="why-section"><span class="why-label">⚖️ Key trade-off</span><span class="why-text">${s.tradeoff}</span></div>` : ""}
      ${s.rag    ? `<div class="why-section rag-section"><span class="why-label">💡 Farming tip</span><span class="why-text">${s.rag}</span></div>` : ""}
      ${(!s.market && !s.day && !s.tradeoff && !s.rag) ? `<p class="report-why">${s.fallback}</p>` : ""}
    </div>`;
}

// ---------- Agent Workflow Visualization ----------
function renderAgentWorkflow(status) {
  // status: 'idle' | 'research' | 'risk' | 'supervisor' | 'done'
  const steps = [
    { id: "wf-input",      icon: "🌾", label: "Farmer Input",         done: true },
    { id: "wf-supervisor", icon: "🧠", label: "Supervisor Agent",     done: ["research","risk","supervisor","done"].includes(status) },
    { id: "wf-research",   icon: "🔍", label: "Market Research Agent",running: status === "research", done: ["risk","supervisor","done"].includes(status) },
    { id: "wf-risk",       icon: "⚖️", label: "Risk Analyst Agent",   running: status === "risk",     done: ["done"].includes(status) },
    { id: "wf-rec",        icon: "✅", label: "Recommendation",        done: status === "done" },
  ];
  return `
    <div class="agent-workflow">
      ${steps.map((s, i) => `
        <div class="wf-step ${s.done ? "wf-done" : ""} ${s.running ? "wf-running" : ""}">
          <div class="wf-icon">${s.icon}</div>
          <div class="wf-label">${s.label}</div>
          ${s.running ? `<div class="wf-pulse"></div>` : ""}
        </div>
        ${i < steps.length - 1 ? `<div class="wf-arrow ${s.done ? "wf-arrow-done" : ""}">→</div>` : ""}
      `).join("")}
    </div>`;
}

// ---------- Risk Meter ----------
function renderRiskMeter(label, probLoss) {
  const pct = parseFloat(probLoss) || 0;
  // map label to position 0-100
  const l = (label || "").toLowerCase();
  let pos = 20;
  if (l.includes("medium")) pos = 55;
  if (l.includes("high")) pos = 85;

  const color = pos < 40 ? "#4caf50" : pos < 70 ? "#ffc107" : "#f44336";
  const bgGradient = `linear-gradient(to right, #1a3a1a 0%, #4caf50 33%, #ffc107 66%, #f44336 100%)`;

  return `
    <div class="risk-meter-wrap">
      <div class="risk-meter-bar" style="background:${bgGradient}">
        <div class="risk-needle" style="left:${pos}%"></div>
      </div>
      <div class="risk-meter-labels">
        <span>Low</span><span>Medium</span><span>High</span>
      </div>
      <div class="risk-meter-val" style="color:${color}">${label || "—"} Risk &nbsp;·&nbsp; P(Loss): ${pct.toFixed(1)}%</div>
    </div>`;
}

// ---------- Confidence Score Badge ----------
function renderConfidenceBadge(confidence) {
  if (confidence === undefined || confidence === null) return "";
  const pct = Math.round(confidence);
  const color = pct >= 80 ? "#4caf50" : pct >= 60 ? "#ffc107" : "#f44336";
  return `
    <div class="exec-card">
      <div class="exec-label">Model Confidence</div>
      <div class="exec-value" style="color:${color}">${pct}%</div>
    </div>`;
}

// ---------- Data Source Badge ----------
function renderDataBadge(usedRealPrices) {
  if (usedRealPrices === undefined) return "";
  return usedRealPrices
    ? `<span class="data-badge data-badge-live">✅ Live Mandi Data (data.gov.in)</span>`
    : `<span class="data-badge data-badge-est">🔶 Model Estimate (no live match)</span>`;
}

// ---------- Perishability Badge ----------
function renderPerishBadge(pClass, shelfDays) {
  if (!pClass) return "";
  const l = pClass.toLowerCase();
  const cls = l.includes("high") ? "perish-high" : l.includes("low") ? "perish-low" : "perish-med";
  const days = shelfDays ? ` · ${shelfDays}d shelf life` : "";
  return `<span class="perish-badge ${cls}">🥬 ${pClass}${days}</span>`;
}

// ---------- Spoilage Countdown ----------
function renderSpoilageCountdown(shelfDays, sellDay) {
  if (!shelfDays) return "";
  const remaining = Math.max(0, shelfDays - (sellDay || 0));
  const urgent = remaining <= 2;
  return `<div class="spoilage-countdown ${urgent ? "spoilage-urgent" : ""}">
    ⏳ Sell within <strong>${remaining} day${remaining !== 1 ? "s" : ""}</strong> before spoilage exceeds safe threshold
  </div>`;
}

// ---------- Monte Carlo Summary ----------
function renderMonteCarloSummary(card) {
  const mean = parseFloat(card.expected_revenue?.replace(/[^\d.-]/g, "")) || 0;
  const std  = card.revenue_std || 0;
  const cvar = parseFloat(card.cvar?.replace(/[^\d.-]/g, "")) || 0;
  const varV = card.var_95 || 0;
  const prob = card.prob_loss_raw || 0;
  const n    = card.n_sims || 1500;

  const lo = mean - std;
  const hi = mean + std;

  return `
    <div class="mc-summary">
      <div class="mc-title">🎲 Monte Carlo Simulation — ${n.toLocaleString()} trials</div>
      <div class="mc-row">
        <span class="mc-label">Mean ± Std</span>
        <span class="mc-val">${fmtRupeeNumber(String(mean))} ± ${fmtRupeeNumber(String(std))}</span>
      </div>
      <div class="mc-range-bar-wrap">
        <div class="mc-range-outer">
          <div class="mc-range-fill" style="left:0;width:100%"></div>
          <div class="mc-range-mean" style="left:50%"></div>
        </div>
        <div class="mc-range-labels">
          <span>${fmtRupeeNumber(String(Math.round(lo)))}</span>
          <span>Mean</span>
          <span>${fmtRupeeNumber(String(Math.round(hi)))}</span>
        </div>
      </div>
      <div class="mc-row">
        <span class="mc-label">VaR 95%</span>
        <span class="mc-val warn">${fmtRupeeNumber(String(varV))}</span>
        <span class="mc-label" style="margin-left:16px">CVaR 95%</span>
        <span class="mc-val warn">${fmtRupeeNumber(String(cvar))}</span>
      </div>
      <div class="mc-row">
        <span class="mc-label">P(Loss)</span>
        <div class="mc-prob-bar-wrap">
          <div class="mc-prob-bar" style="width:${Math.min(prob, 100)}%"></div>
          <span class="mc-prob-label">${prob.toFixed(1)}%</span>
        </div>
      </div>
    </div>`;
}

// ---------- Day-by-Day Sparkline ----------
function renderDaySparkline(ranked_full, winnerMarket) {
  if (!ranked_full || !ranked_full.length) return "";
  const rows = ranked_full.filter(r => r.market === winnerMarket);
  if (!rows.length) return "";
  rows.sort((a, b) => a.sell_day - b.sell_day);

  const values = rows.map(r => r.ce);
  const max = Math.max(...values);
  const min = Math.min(...values);
  const range = max - min || 1;

  const bars = rows.map(r => {
    const h = Math.max(10, Math.round(((r.ce - min) / range) * 60));
    const isWinner = r.sell_day === rows.reduce((a, b) => b.ce > a.ce ? b : a).sell_day;
    return `
      <div class="spark-col">
        <div class="spark-bar ${isWinner ? "spark-best" : ""}" style="height:${h}px" title="Day ${r.sell_day}: ${fmtRupeeNumber(String(r.ce))}"></div>
        <div class="spark-day">D${r.sell_day}</div>
      </div>`;
  }).join("");

  return `
    <div class="sparkline-wrap">
      <div class="panel-subtitle">📅 Day-by-Day CE Revenue at ${winnerMarket}</div>
      <div class="spark-bars">${bars}</div>
      <div class="spark-note">Taller = higher risk-adjusted revenue. Best day highlighted.</div>
    </div>`;
}

// ---------- Market Ranking Table ----------
function renderMarketRankingTable(market_summary, mapData) {
  if (!market_summary || !market_summary.length) return "";
  const rows = market_summary.map((m, i) => {
    const dist = (mapData?.markets || []).find(x => x.name === m.market)?.distance_km || "—";
    const travelEst = dist !== "—" ? `~${Math.round(dist / 40 * 60)} min` : "—";
    const winBadge = m.is_winner ? `<span class="winner-badge">⭐ Best</span>` : "";
    return `
      <tr class="${m.is_winner ? "row-winner" : ""}">
        <td>${i + 1}</td>
        <td>${m.market} ${winBadge}</td>
        <td class="num">${dist !== "—" ? dist + " km" : "—"}</td>
        <td class="num">${travelEst}</td>
        <td class="num">${fmtRupeeNumber(String(m.best_ce))}</td>
        <td class="num">${m.prob_loss}%</td>
        <td>${trendArrow(m.trend_pct)}</td>
        <td><span class="badge ${getRiskBadgeClass(m.risk_score)}">${m.risk_score}</span></td>
      </tr>`;
  }).join("");

  return `
    <div class="panel-subtitle" style="margin-top:20px">🏪 Market Ranking</div>
    <div class="market-rank-scroll">
      <table class="dash-table">
        <thead><tr>
          <th>#</th><th>Market</th><th>Distance</th><th>Travel</th>
          <th>CE Revenue</th><th>P(Loss)</th><th>Trend</th><th>Risk</th>
        </tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </div>`;
}

// ---------- Decision Comparison Table ----------
function renderComparisonTable(alternatives, best, card) {
  if (!alternatives || !alternatives.length) return "";

  // build full list including best as #1
  const allRows = [
    {
      label: `${card.market_name || ""} day${card.sell_day} ${card.storage_type}`,
      market: card.market_name,
      sell_day: card.sell_day,
      storage_type: card.storage_type,
      ce: parseFloat(card.ce_revenue?.replace(/[^\d.-]/g, "")) || 0,
      mean: parseFloat(card.expected_revenue?.replace(/[^\d.-]/g, "")) || 0,
      cvar: parseFloat(card.cvar?.replace(/[^\d.-]/g, "")) || 0,
      prob_loss: card.prob_loss,
      risk_score: card.risk_score_label,
      isBest: true,
    },
    ...alternatives.map(a => ({
      ...a,
      ce: parseFloat(a.ce) || 0,
      mean: parseFloat(a.mean) || 0,
      cvar: parseFloat(a.cvar) || 0,
      isBest: false,
    }))
  ];

  const tableRows = allRows.map((r, i) => `
    <tr class="${r.isBest ? "row-winner" : ""}">
      <td>${i + 1} ${r.isBest ? "⭐" : ""}</td>
      <td>${r.market || ""}</td>
      <td class="num">Day ${r.sell_day}</td>
      <td>${r.storage_type || ""}</td>
      <td class="num">${fmtRupeeNumber(String(r.ce))}</td>
      <td class="num">${fmtRupeeNumber(String(r.mean))}</td>
      <td class="num warn">${fmtRupeeNumber(String(r.cvar))}</td>
      <td>${r.prob_loss}</td>
      <td><span class="badge ${getRiskBadgeClass(r.risk_score)}">${r.risk_score || "—"}</span></td>
      <td>${trendArrow(r.trend_pct)}</td>
    </tr>`).join("");

  return `
    <div class="panel-subtitle" style="margin-top:20px">📊 Strategy Comparison</div>
    <div class="comparison-scroll">
      <table class="dash-table">
        <thead><tr>
          <th>#</th><th>Market</th><th>Day</th><th>Storage</th>
          <th>CE Revenue</th><th>Mean Revenue</th><th>CVaR 95%</th>
          <th>P(Loss)</th><th>Risk</th><th>Trend</th>
        </tr></thead>
        <tbody>${tableRows}</tbody>
      </table>
    </div>`;
}

// ---------- Top-3 Strategy Cards ----------
function renderTopStrategyCards(alternatives, card) {
  if (!alternatives || !alternatives.length) return "";
  const top = alternatives.slice(0, 3);
  const cards = top.map((a, i) => `
    <div class="strat-card">
      <div class="strat-rank">#${i + 2}</div>
      <div class="strat-name">${a.market || a.label}</div>
      <div class="strat-detail">Day ${a.sell_day} · ${a.storage_type}</div>
      <div class="strat-ce">${fmtRupeeNumber(a.ce)}</div>
      <div class="strat-meta">
        <span class="badge ${getRiskBadgeClass(a.risk_score)}">${a.risk_score}</span>
        <span class="strat-ploss">P(Loss) ${a.prob_loss}</span>
      </div>
    </div>`).join("");

  return `
    <div class="panel-subtitle" style="margin-top:18px">🥈 Other Top Strategies</div>
    <div class="strat-cards-row">${cards}</div>`;
}

// ---------- RAG Citation Panel ----------
function renderRAGPanel(tipResults) {
  if (!tipResults || !tipResults.length) return "";
  const items = tipResults.slice(0, 3).map(r => `
    <div class="rag-cite-item">
      <div class="rag-cite-text">${r.text || ""}</div>
      ${r.relevance_score !== undefined ? `<div class="rag-cite-score">Relevance: ${(r.relevance_score * 100).toFixed(0)}%</div>` : ""}
    </div>`).join("");

  return `
    <details class="rag-panel">
      <summary>📚 RAG Knowledge Sources (${tipResults.length} retrieved)</summary>
      <div class="rag-cite-list">${items}</div>
    </details>`;
}

// ---------- Profit Waterfall ----------
function renderProfitWaterfall(card) {
  const gross = parseFloat(card.expected_revenue?.replace(/[^\d.-]/g, "")) || 0;
  const transport = card.transport_cost_rs || 0;
  const spoilagePct = card.spoilage_pct || 0;
  const spoilageLoss = gross * (spoilagePct / 100);
  const net = gross - transport - spoilageLoss;

  if (!gross) return "";

  const max = gross;
  const items = [
    { label: "Gross Revenue", val: gross,         color: "#4caf50", subtract: false },
    { label: "Transport",     val: -transport,     color: "#f44336", subtract: true  },
    { label: "Spoilage Loss", val: -spoilageLoss,  color: "#ff9800", subtract: true  },
    { label: "Net Revenue",   val: net,            color: "#2196f3", subtract: false },
  ];

  const bars = items.map(it => {
    const pct = Math.max(4, Math.abs(it.val) / max * 100);
    return `
      <div class="waterfall-row">
        <div class="wf-row-label">${it.label}</div>
        <div class="wf-bar-wrap">
          <div class="wf-bar" style="width:${pct}%;background:${it.color}"></div>
        </div>
        <div class="wf-row-val" style="color:${it.color}">${it.subtract ? "-" : ""}${fmtRupeeNumber(String(Math.abs(it.val).toFixed(0)))}</div>
      </div>`;
  }).join("");

  return `
    <div class="waterfall-wrap">
      <div class="panel-subtitle">💰 Revenue Waterfall</div>
      ${bars}
    </div>`;
}

// ---------- Break-Even Calculator ----------
function renderBreakEven(breakEvenPrice) {
  if (!breakEvenPrice && breakEvenPrice !== 0) return "";
  return `
    <div class="breakeven-box">
      💲 Break-even: You need at least <strong>${fmtRupeeNumber(String(breakEvenPrice))}/kg</strong> to cover transport & storage.
    </div>`;
}

// ---------- Assumption Box ----------
function renderAssumptionBox(card) {
  const crop = document.getElementById("crop")?.value || "—";
  const qty  = document.getElementById("quantity_kg")?.value || "—";
  const veh  = document.getElementById("vehicle_type")?.value || "—";
  const risk = document.getElementById("risk_profile")?.value || "medium";
  const lambdaMap = { low: "1.2", medium: "0.6", high: "0.2" };
  return `
    <details class="assumption-box">
      <summary>🔐 Assumptions Made</summary>
      <ul class="assumption-list">
        <li>Crop: <strong>${crop}</strong></li>
        <li>Quantity: <strong>${qty} kg</strong></li>
        <li>Vehicle: <strong>${veh.replace(/_/g," ")}</strong></li>
        <li>Risk aversion λ: <strong>${lambdaMap[risk] || "0.6"} (${risk})</strong></li>
        <li>Price source: <strong>${card.used_real_prices ? "data.gov.in (live)" : "Estimated model"}</strong></li>
        <li>Monte Carlo trials: <strong>${(card.n_sims || 1500).toLocaleString()}</strong></li>
      </ul>
    </details>`;
}

// ---------- Audit Trail ----------
function renderAuditTrail() {
  return `<div class="audit-trail">🕐 Analysis run at ${new Date().toLocaleString("en-IN")} · AgriMax Pro v5 · Model: LLaMA via Groq</div>`;
}

// ---------- Map ----------
let mapCounter = 0;
function renderMiniMap(mapData, winnerMarketName, cardMarkets) {
  if (!mapData || !mapData.markets || !mapData.markets.length) return "";
  mapCounter++;
  const mapId = `map-${mapCounter}`;
  setTimeout(() => {
    const el = document.getElementById(mapId);
    if (!el || typeof L === "undefined") return;
    const map = L.map(mapId, { zoomControl: true, attributionControl: false });
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png").addTo(map);

    const points = [[mapData.farm_lat, mapData.farm_lon]];
    const farmIcon = L.divIcon({
      className: "", html: `<div class="map-pin farm-pin">🏠</div>`, iconSize: [30, 30], iconAnchor: [15, 28],
    });
    L.marker([mapData.farm_lat, mapData.farm_lon], { icon: farmIcon })
      .addTo(map)
      .bindPopup(`<b>📍 ${mapData.location}</b><br>Your farm`);

    const sorted = [...mapData.markets].sort((a, b) => a.distance_km - b.distance_km);
    const tierColors = ["#2e7d32", "#f9a825", "#c2272f"];

    sorted.forEach((m, i) => {
      points.push([m.lat, m.lon]);
      let color;
      if (winnerMarketName && m.name === winnerMarketName) {
        color = "#2e7d32";
      } else if (winnerMarketName) {
        color = i === 0 ? "#f9a825" : tierColors[Math.min(i, 2)];
      } else {
        color = i === 0 ? "#2e7d32" : i < sorted.length - 1 ? "#f9a825" : "#c2272f";
      }
      const marketIcon = L.divIcon({
        className: "", html: `<div class="map-pin market-pin" style="background:${color}">${i + 1}</div>`,
        iconSize: [26, 26], iconAnchor: [13, 24],
      });

      // enrich popup with price/weather from cardMarkets
      const cm = (cardMarkets || []).find(x => x.market === m.name) || {};
      const popup = `
        <b>${m.name}</b><br>
        ${m.distance_km} km · ~${Math.round(m.distance_km / 40 * 60)} min<br>
        ${cm.best_ce ? "CE Rev: ₹" + Math.round(cm.best_ce).toLocaleString("en-IN") : ""}
        ${cm.risk_score ? " · " + cm.risk_score + " Risk" : ""}`;

      L.marker([m.lat, m.lon], { icon: marketIcon }).addTo(map).bindPopup(popup);

      // distance label on line
      const midLat = (mapData.farm_lat + m.lat) / 2;
      const midLon = (mapData.farm_lon + m.lon) / 2;
      L.polyline([[mapData.farm_lat, mapData.farm_lon], [m.lat, m.lon]], {
        color: color, weight: 2, opacity: 0.55, dashArray: "5,6",
      }).addTo(map);
      L.tooltip({ permanent: true, direction: "center", className: "dist-label" })
        .setContent(`${m.distance_km} km`)
        .setLatLng([midLat, midLon])
        .addTo(map);
    });

    map.fitBounds(points, { padding: [30, 30] });
  }, 60);

  return `
    <div class="panel-subtitle">📍 Nearby Markets &amp; Routes</div>
    <div id="${mapId}" class="dash-map"></div>
    <div class="map-legend">
      <span><i class="legend-dot" style="background:#2e7d32"></i> Recommended</span>
      <span><i class="legend-dot" style="background:#f9a825"></i> Alternative</span>
      <span><i class="legend-dot" style="background:#c2272f"></i> Farthest</span>
      <span><i class="legend-dot" style="background:#9a6b00; border-radius:4px;">🏠</i> Your farm</span>
    </div>`;
}

// ---------- Suggestion Chips ----------
function renderSuggestionChips(card) {
  const market = card.market_name || "this market";
  const day = card.sell_day !== undefined ? card.sell_day : 1;
  const chips = [
    `What if I had 1000 kg instead?`,
    `Compare cold storage vs ambient at ${market}`,
    `What's the spoilage risk if I wait ${day + 2} days?`,
    `Try selling at day 0`,
  ];
  return `
    <div class="suggestion-chips">
      ${chips.map(c => `<button class="chip" onclick="submitChip(this)">${c}</button>`).join("")}
    </div>`;
}

function submitChip(btn) {
  const text = btn.textContent;
  const chatInput = document.getElementById("chat-message");
  const apiKey = document.getElementById("api_key").value.trim();
  chatInput.value = text;
  switchToTab("chat");
  // auto-submit
  document.getElementById("chat-form").dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }));
}

// ============================================================
// AGENT WORKFLOW VIZ STATE
// ============================================================
let workflowInterval = null;
function startWorkflowAnimation() {
  const el = document.getElementById("workflow-panel");
  if (!el) return;
  const steps = ["research", "risk", "supervisor"];
  let idx = 0;
  el.innerHTML = renderAgentWorkflow("research");
  workflowInterval = setInterval(() => {
    idx = (idx + 1) % steps.length;
    el.innerHTML = renderAgentWorkflow(steps[idx]);
  }, 2800);
}
function stopWorkflowAnimation(done) {
  clearInterval(workflowInterval);
  workflowInterval = null;
  const el = document.getElementById("workflow-panel");
  if (el) el.innerHTML = renderAgentWorkflow(done ? "done" : "idle");
}

// ============================================================
// Live status banner steps
// ============================================================
let statusInterval = null;
const STATUS_STEPS = [
  "🔍 Market Research Agent scanning nearby APMC markets…",
  "🌦️ Fetching weather risk data for candidate markets…",
  "💹 Retrieving price data (data.gov.in / estimated)…",
  "⚖️ Risk Analyst Agent running 1,500 Monte Carlo simulations…",
  "📊 Computing CVaR, VaR, and certainty-equivalent revenues…",
  "📚 RAG knowledge base: retrieving practical farming tips…",
  "🧠 Supervisor synthesising final recommendation…",
];
function startStatusCycle() {
  let i = 0;
  setRunStatus("running", STATUS_STEPS[0]);
  statusInterval = setInterval(() => {
    i = Math.min(i + 1, STATUS_STEPS.length - 1);
    setRunStatus("running", STATUS_STEPS[i]);
  }, 2500);
}
function stopStatusCycle() {
  clearInterval(statusInterval);
  statusInterval = null;
}

// ============================================================
// Dashboard: SINGLE-MARKET mode
// ============================================================
function renderSingleDashboard(card, mapData) {
  const riskFactor = (card.factors || []).find(f => /risk score/i.test(f.factor));
  const factorRows = (card.factors || []).map(f =>
    `<tr><td>${f.factor}</td><td class="num">${f.value}</td></tr>`
  ).join("");

  const winnerMarket = card.market_name || (card.recommendation || "").split(",")[0].trim();

  return `
    <div class="report-card">
      <div class="report-header">
        <div>
          <span class="status-pill">✅ Analysis Complete</span>
          ${renderPerishBadge(card.perishability_class, card.shelf_life_days)}
          <h2>${card.recommendation}</h2>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:8px">
          ${riskFactor ? `<span class="badge ${getRiskBadgeClass(riskFactor.value)}">${riskFactor.value} Risk</span>` : ""}
          ${renderDataBadge(card.used_real_prices)}
        </div>
      </div>

      ${renderStructuredWhy(card.why)}

      ${card.agents_consulted ? `
      <div class="agents-row">
        ${card.agents_consulted.split(",").map(a => `<span class="agent-chip">🤖 ${a.trim()}</span>`).join("")}
      </div>` : ""}

      <div class="exec-summary-title">EXECUTIVE SUMMARY</div>
      <div class="exec-grid">
        <div class="exec-card highlight">
          <div class="exec-label">Expected Revenue</div>
          <div class="exec-value">${fmtMoney(card.expected_revenue)}</div>
        </div>
        <div class="exec-card highlight">
          <div class="exec-label">Risk-Adjusted (CE) Revenue</div>
          <div class="exec-value">${fmtMoney(card.ce_revenue)}</div>
        </div>
        <div class="exec-card">
          <div class="exec-label">Worst-Case (CVaR 95%)</div>
          <div class="exec-value warn">${fmtMoney(card.cvar)}</div>
        </div>
        <div class="exec-card">
          <div class="exec-label">Probability of Loss</div>
          <div class="exec-value">${card.prob_loss || "—"}</div>
        </div>
        ${renderConfidenceBadge(card.confidence)}
      </div>

      ${renderRiskMeter(card.risk_score_label, card.prob_loss_raw)}
      ${renderSpoilageCountdown(card.shelf_life_days, card.sell_day)}

      <div class="report-grid">
        <div class="report-col">
          ${factorRows ? `
          <div class="panel-subtitle">Why This Was Chosen — Factor Breakdown</div>
          <table class="dash-table"><tbody>${factorRows}</tbody></table>` : ""}

          ${renderBreakEven(card.break_even_price_rs_per_kg)}
          ${renderProfitWaterfall(card)}
          ${renderMonteCarloSummary(card)}
          ${renderDaySparkline(card.ranked_strategies_full, winnerMarket)}
        </div>
        <div class="report-col">
          ${renderMiniMap(mapData, winnerMarket, card.market_summary)}
          ${renderMarketRankingTable(card.market_summary, mapData)}
        </div>
      </div>

      ${renderTopStrategyCards(card.alternatives, card)}
      ${renderComparisonTable(card.alternatives, null, card)}

      ${card.practical_tip ? `
      <div class="tip-box"><span class="tip-icon">💡</span> <strong>Practical tip:</strong> ${card.practical_tip}</div>` : ""}

      ${renderRAGPanel(card.tip_results)}

      ${card.data_sources ? `<div class="sources-note">📊 <strong>Data sources:</strong> ${card.data_sources}</div>` : ""}

      ${renderAssumptionBox(card)}
      ${renderAuditTrail()}

      <details class="raw-reasoning">
        <summary>Show full agent reasoning</summary>
        <pre>${card.raw}</pre>
      </details>

      <div class="print-btn-row">
        <button class="secondary-btn" onclick="window.print()" style="width:auto;margin-top:10px">🖨️ Print / Export Report</button>
      </div>
    </div>

    ${renderSuggestionChips(card)}`;
}

// ---------- Dashboard: SPLIT (multi-market) mode ----------
function renderSplitDashboard(card, mapData) {
  const legs = card.legs || [];

  const legRows = legs.map((l, i) => `
    <tr>
      <td><strong>${i + 1}. ${l.market}</strong></td>
      <td class="num">${l.qty_kg ? l.qty_kg + " kg" : "—"}</td>
      <td class="num">Day ${l.sell_day}</td>
      <td>${l.storage}</td>
      <td class="num">${fmtMoney(l.expected_revenue)}</td>
      <td class="num">${fmtMoney(l.ce_revenue)}</td>
      <td class="num warn">${fmtMoney(l.cvar)}</td>
      <td><span class="badge ${getRiskBadgeClass(l.risk_score)}">${l.risk_score}</span></td>
    </tr>
  `).join("");

  const detailCards = legs.map((l, i) => `
    <div class="split-leg-card">
      <div class="split-leg-header">
        <span class="split-leg-num">${i + 1}</span>
        <strong>${l.market}</strong>
        <span class="badge ${getRiskBadgeClass(l.risk_score)}">${l.risk_score} Risk</span>
      </div>
      <div class="split-leg-grid">
        <div><span class="leg-label">Quantity</span><span class="leg-val">${l.qty_kg ? l.qty_kg + " kg" : "—"}</span></div>
        <div><span class="leg-label">Sell Day</span><span class="leg-val">Day ${l.sell_day}</span></div>
        <div><span class="leg-label">Storage</span><span class="leg-val">${l.storage}</span></div>
        <div><span class="leg-label">Expected Rev.</span><span class="leg-val">${fmtMoney(l.expected_revenue)}</span></div>
        <div><span class="leg-label">CE Revenue</span><span class="leg-val">${fmtMoney(l.ce_revenue)}</span></div>
        <div><span class="leg-label">CVaR 95%</span><span class="leg-val warn">${fmtMoney(l.cvar)}</span></div>
        <div><span class="leg-label">P(Loss)</span><span class="leg-val">${l.prob_loss}</span></div>
        <div><span class="leg-label">Transport</span><span class="leg-val">${fmtMoney(l.transport_cost)}</span></div>
        <div><span class="leg-label">Spoilage</span><span class="leg-val">${l.spoilage_pct}</span></div>
        <div><span class="leg-label">Weather</span><span class="leg-val">${l.weather_risk}</span></div>
      </div>
    </div>
  `).join("");

  return `
    <div class="report-card">
      <div class="report-header">
        <div>
          <span class="status-pill split-pill">🔀 Split-Market Analysis</span>
          <h2>${card.recommendation}</h2>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:8px">
          <span class="badge ${getRiskBadgeClass(card.overall_risk)}">${card.overall_risk} Overall Risk</span>
          ${renderDataBadge(card.used_real_prices)}
        </div>
      </div>

      <p class="report-why">${card.why}</p>

      ${card.agents_consulted ? `
      <div class="agents-row">
        ${card.agents_consulted.split(",").map(a => `<span class="agent-chip">🤖 ${a.trim()}</span>`).join("")}
      </div>` : ""}

      <div class="exec-summary-title">COMBINED TOTALS</div>
      <div class="exec-grid">
        <div class="exec-card highlight">
          <div class="exec-label">Total Expected Revenue</div>
          <div class="exec-value">${fmtMoney(card.expected_revenue)}</div>
        </div>
        <div class="exec-card highlight">
          <div class="exec-label">Total CE Revenue</div>
          <div class="exec-value">${fmtMoney(card.ce_revenue)}</div>
        </div>
        <div class="exec-card">
          <div class="exec-label">Combined CVaR 95%</div>
          <div class="exec-value warn">${fmtMoney(card.cvar)}</div>
        </div>
        <div class="exec-card">
          <div class="exec-label">Avg. P(Loss)</div>
          <div class="exec-value">${card.prob_loss || "—"}</div>
        </div>
      </div>

      <div class="panel-subtitle" style="margin-top:20px;">Per-Market Breakdown</div>
      <div class="split-legs-container">${detailCards}</div>

      <div class="split-table-wrap">
        <table class="dash-table">
          <thead>
            <tr><th>Market</th><th>Qty</th><th>Day</th><th>Storage</th>
            <th>Expected Rev.</th><th>CE Rev.</th><th>CVaR 95%</th><th>Risk</th></tr>
          </thead>
          <tbody>${legRows}</tbody>
        </table>
      </div>

      ${card.practical_tip ? `
      <div class="tip-box"><span class="tip-icon">💡</span> <strong>Practical tip:</strong> ${card.practical_tip}</div>` : ""}

      <div class="report-grid" style="margin-top:16px;">
        <div class="report-col" style="grid-column: 1/-1;">
          ${renderMiniMap(mapData, null, null)}
        </div>
      </div>

      ${card.data_sources ? `<div class="sources-note">📊 <strong>Data sources:</strong> ${card.data_sources}</div>` : ""}
      ${renderAuditTrail()}

      <details class="raw-reasoning">
        <summary>Show full agent reasoning</summary>
        <pre>${card.raw}</pre>
      </details>

      <div class="print-btn-row">
        <button class="secondary-btn" onclick="window.print()" style="width:auto;margin-top:10px">🖨️ Print / Export Report</button>
      </div>
    </div>`;
}

// ---------- Top-level dashboard dispatcher ----------
function renderDashboard(card, mapData) {
  document.getElementById("results-empty").classList.add("hidden");
  const container = document.getElementById("results-content");
  if (!card) return;
  if (card.mode === "split") {
    container.innerHTML = renderSplitDashboard(card, mapData);
  } else {
    container.innerHTML = renderSingleDashboard(card, mapData);
  }
  stopWorkflowAnimation(true);
}

function setRunStatus(state, text) {
  const el = document.getElementById("run-status");
  el.className = "run-status " + state;
  el.textContent = text;
  el.classList.remove("hidden");
}

// ---------- Form submit -> run analysis ----------
const form = document.getElementById("advisor-form");
const runBtn = document.getElementById("run-btn");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const apiKey = document.getElementById("api_key").value.trim();
  if (!apiKey) {
    setRunStatus("error", "⚠️ Please enter your Groq API key first.");
    return;
  }

  const crop = document.getElementById("crop").value.trim();
  const quantity = document.getElementById("quantity_kg").value;
  const maxDays = document.getElementById("max_days").value;
  const location = document.getElementById("location").value.trim();
  const risk = document.getElementById("risk_profile").value;
  const language = document.getElementById("language").value;
  const vehicleType = document.getElementById("vehicle_type").value;

  const message = `I have ${quantity}kg ${crop} in ${location}. I can wait up to ${maxDays} days ` +
    `before I must sell. My risk tolerance is ${risk}. Please run a full risk-adjusted strategy ` +
    `evaluation across nearby markets and give me your recommendation.`;

  runBtn.disabled = true;
  runBtn.textContent = "⏳ Analysing…";
  startStatusCycle();
  startWorkflowAnimation();
  switchToTab("results");

  try {
    const resp = await fetch("/agrimax/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ api_key: apiKey, message, language, vehicle_type: vehicleType })
    });
    const data = await resp.json();

    stopStatusCycle();

    if (!resp.ok) {
      setRunStatus("error", "⚠️ " + (data.error || "Something went wrong."));
      stopWorkflowAnimation(false);
      return;
    }

    if (data.card && (data.card.recommendation || data.card.legs)) {
      renderDashboard(data.card, data.map);
      setRunStatus("success", "✅ Analysis complete.");
    } else {
      document.getElementById("results-empty").classList.add("hidden");
      document.getElementById("results-content").innerHTML =
        `<div class="plain-reply-card">${data.reply}</div>`;
      setRunStatus("success", "✅ Done — see note below (try adding a location if this looks incomplete).");
      stopWorkflowAnimation(false);
    }

    appendChatBubble("user", message);
    appendChatBubble("agent", data.reply, !!(data.card && (data.card.recommendation || data.card.legs)));

  } catch (err) {
    stopStatusCycle();
    stopWorkflowAnimation(false);
    setRunStatus("error", "⚠️ Network error: " + err);
  } finally {
    runBtn.disabled = false;
    runBtn.textContent = "▶ Run Analysis";
  }
});

document.getElementById("reset-btn").addEventListener("click", async () => {
  await fetch("/agrimax/reset", { method: "POST" });
  document.getElementById("results-content").innerHTML = "";
  document.getElementById("results-empty").classList.remove("hidden");
  document.getElementById("run-status").classList.add("hidden");
  const wp = document.getElementById("workflow-panel");
  if (wp) wp.innerHTML = renderAgentWorkflow("idle");
  document.getElementById("chat-window").innerHTML =
    `<div class="msg agent"><div class="bubble">👋 Conversation reset. Run a new analysis or ask me something.</div></div>`;
});

document.querySelectorAll(".example-prompt").forEach(el => {
  el.addEventListener("click", () => {
    switchToTab("chat");
    document.getElementById("chat-message").value = el.textContent.trim();
    document.getElementById("chat-message").focus();
  });
});

// ---------- Chat tab ----------
const chatWindow = document.getElementById("chat-window");
const chatForm = document.getElementById("chat-form");
const chatInput = document.getElementById("chat-message");
const chatError = document.getElementById("chat-error");

function appendChatBubble(role, text, hasDashboard) {
  const div = document.createElement("div");
  div.className = "msg " + (role === "user" ? "user" : "agent");
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  if (hasDashboard && role !== "user") {
    const link = document.createElement("span");
    link.className = "bubble-dashboard-link";
    link.textContent = " ↗ View dashboard";
    link.addEventListener("click", () => switchToTab("results"));
    bubble.appendChild(link);
  }
  div.appendChild(bubble);
  chatWindow.appendChild(div);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function addTypingIndicator() {
  const div = document.createElement("div");
  div.className = "msg agent";
  div.id = "typing-indicator";
  div.innerHTML = `<div class="bubble typing"><span class="typing-text">Thinking</span><span class="dots"><span></span><span></span><span></span></span></div>`;
  chatWindow.appendChild(div);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}
function removeTypingIndicator() {
  const el = document.getElementById("typing-indicator");
  if (el) el.remove();
}

chatForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;
  const apiKey = document.getElementById("api_key").value.trim();
  chatError.classList.add("hidden");
  if (!apiKey) {
    chatError.textContent = "⚠️ Please enter your Groq API key in the sidebar first.";
    chatError.classList.remove("hidden");
    return;
  }

  chatInput.value = "";
  appendChatBubble("user", text);
  addTypingIndicator();

  try {
    const resp = await fetch("/agrimax/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        api_key: apiKey,
        message: text,
        language: document.getElementById("language").value,
        vehicle_type: document.getElementById("vehicle_type").value,
      })
    });
    const data = await resp.json();
    removeTypingIndicator();

    if (!resp.ok) {
      chatError.textContent = "⚠️ " + (data.error || "Something went wrong.");
      chatError.classList.remove("hidden");
      return;
    }

    const hasDashboard = !!(data.card && (data.card.recommendation || data.card.legs));
    appendChatBubble("agent", data.reply, hasDashboard);

    if (hasDashboard) {
      renderDashboard(data.card, data.map);
      setRunStatus("success", "✅ Dashboard updated from your follow-up. Switching now…");
      setTimeout(() => switchToTab("results"), 800);
    }
  } catch (err) {
    removeTypingIndicator();
    chatError.textContent = "⚠️ Network error: " + err;
    chatError.classList.remove("hidden");
  }
});

// ---------- Init workflow panel ----------
(function initWorkflow() {
  const el = document.getElementById("workflow-panel");
  if (el) el.innerHTML = renderAgentWorkflow("idle");
})();
