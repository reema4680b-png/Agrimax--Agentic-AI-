"""
tools.py — the quantitative "world model" the agent calls into.
----------------------------------------------------------------------
v4: multi-market split support, per-trial Monte Carlo sampling,
distance-ordered market generation, and all previous real-data
integrations (Nominatim / Open-Meteo / data.gov.in) with safe
mock fallbacks.

REAL DATA SOURCES USED (free, no key needed unless noted):
  - geocode_location(): OpenStreetMap Nominatim (free, no key)
  - get_weather_risk(): Open-Meteo forecast API (free, no key)
  - get_real_market_prices(): data.gov.in Agmarknet dataset
  - All real calls fall back to seeded mock generators if the
    network/API is unavailable.
----------------------------------------------------------------------
"""

import csv
import hashlib
import json
import math
import os
import random
import statistics
from datetime import date

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
CROP_DB_PATH = os.path.join(DATA_DIR, "crops.csv")
DATA_GOV_IN_API_KEY = os.environ.get("DATA_GOV_IN_API_KEY", "")
AGMARKNET_RESOURCE_ID = "9ef84268-d588-465a-a308-a864a43d0070"


def _load_crop_db():
    db = {}
    with open(CROP_DB_PATH, newline="") as f:
        for row in csv.DictReader(f):
            db[row["crop"].strip().lower()] = {
                "shelf_life_days": float(row["shelf_life_days"]),
                "decay_rate_pct_per_day": float(row["decay_rate_pct_per_day"]),
                "price_volatility_pct": float(row["price_volatility_pct"]),
                "perishability_class": row["perishability_class"],
            }
    return db


CROP_DB = _load_crop_db()


def list_supported_crops():
    return sorted(CROP_DB.keys())


def get_crop_profile(crop: str):
    crop = crop.strip().lower()
    if crop not in CROP_DB:
        return {
            "shelf_life_days": 10.0,
            "decay_rate_pct_per_day": 5.0,
            "price_volatility_pct": 3.0,
            "perishability_class": "medium (estimated default)",
        }
    return CROP_DB[crop]


def _seeded_rng(*parts):
    key = "|".join(str(p) for p in parts)
    seed = int(hashlib.sha256(key.encode()).hexdigest(), 16) % (2**32)
    return random.Random(seed)


# ----------------------------------------------------------------------
# Geocoding
# ----------------------------------------------------------------------
def geocode_location(location: str):
    if REQUESTS_AVAILABLE:
        try:
            resp = requests.get(
                "https://nominatim.openstreetmap.org/search",
                params={"q": location, "format": "json", "limit": 1},
                headers={"User-Agent": "AgriMax-farmer-advisor/1.0"},
                timeout=6,
            )
            data = resp.json()
            if data:
                return {
                    "lat": float(data[0]["lat"]),
                    "lon": float(data[0]["lon"]),
                    "display_name": data[0].get("display_name", location),
                    "source": "openstreetmap_nominatim",
                }
        except Exception:
            pass
    rng = _seeded_rng(location.strip().lower(), "geocode")
    return {
        "lat": round(rng.uniform(8.0, 28.0), 4),
        "lon": round(rng.uniform(72.0, 88.0), 4),
        "display_name": location,
        "source": "mock_fallback (no network / location not found)",
    }


# ----------------------------------------------------------------------
# Weather risk
# ----------------------------------------------------------------------
def get_weather_risk(lat: float, lon: float):
    if REQUESTS_AVAILABLE:
        try:
            resp = requests.get(
                "https://api.open-meteo.com/v1/forecast",
                params={
                    "latitude": lat,
                    "longitude": lon,
                    "daily": "temperature_2m_max,precipitation_probability_max,relative_humidity_2m_max",
                    "timezone": "auto",
                    "forecast_days": 7,
                },
                timeout=6,
            )
            data = resp.json()
            daily = data.get("daily", {})
            if daily:
                avg_temp = statistics.fmean(daily.get("temperature_2m_max", [30]))
                avg_humidity = statistics.fmean(daily.get("relative_humidity_2m_max", [60]))
                max_rain_prob = max(daily.get("precipitation_probability_max", [0]))
                return _weather_to_risk(avg_temp, avg_humidity, max_rain_prob, source="open-meteo")
        except Exception:
            pass
    rng = _seeded_rng(round(lat, 1), round(lon, 1), "weather")
    avg_temp = rng.uniform(22, 40)
    avg_humidity = rng.uniform(35, 85)
    max_rain_prob = rng.uniform(0, 80)
    return _weather_to_risk(avg_temp, avg_humidity, max_rain_prob, source="mock_fallback (no network)")


def _weather_to_risk(avg_temp, avg_humidity, max_rain_prob, source):
    heat_factor = max(0.0, (avg_temp - 25) / 15)
    humidity_factor = max(0.0, (avg_humidity - 50) / 50)
    spoilage_multiplier = round(1.0 + 0.5 * heat_factor + 0.3 * humidity_factor, 3)
    rain_risk = max_rain_prob / 100.0
    transport_delay_risk = round(rain_risk, 3)
    demand_multiplier = round(1.0 - 0.15 * rain_risk, 3)
    if spoilage_multiplier > 1.3 or rain_risk > 0.6:
        risk_label = "High"
    elif spoilage_multiplier > 1.1 or rain_risk > 0.3:
        risk_label = "Medium"
    else:
        risk_label = "Low"
    return {
        "avg_temp_c": round(avg_temp, 1),
        "avg_humidity_pct": round(avg_humidity, 1),
        "max_rain_probability_pct": round(max_rain_prob, 1),
        "spoilage_multiplier": spoilage_multiplier,
        "transport_delay_risk": transport_delay_risk,
        "demand_multiplier": demand_multiplier,
        "weather_risk_label": risk_label,
        "source": source,
    }


# ----------------------------------------------------------------------
# Market discovery — sorted by distance, coordinates consistent with km
# ----------------------------------------------------------------------
_MARKET_NAME_TEMPLATES = [
    "{loc} APMC Yard",
    "{loc} Wholesale Market",
    "{loc} Mandi",
    "{nearby} Regional Market",
    "{nearby} District Mandi",
]


def find_nearby_markets(location: str, max_markets: int = 4):
    geo = geocode_location(location)
    rng = _seeded_rng(location.strip().lower(), "markets")
    nearby_pool = ["Riverside", "Northgate", "Old Town", "Junction", "Highway", "Central"]
    raw_markets = []
    for i in range(max_markets):
        template = _MARKET_NAME_TEMPLATES[i % len(_MARKET_NAME_TEMPLATES)]
        nearby_word = rng.choice(nearby_pool)
        name = template.format(loc=location.strip().title(), nearby=nearby_word)
        # Each market gets an independently drawn base distance; we sort afterwards
        distance = round(rng.uniform(5, 15) + i * rng.uniform(15, 35), 1)
        bearing = rng.uniform(0, 360)
        # Convert km → degrees consistently (1 deg lat ≈ 111 km)
        lat_offset = (distance / 111.0) * math.cos(math.radians(bearing))
        lon_offset = (distance / (111.0 * math.cos(math.radians(geo["lat"])))) * math.sin(math.radians(bearing))
        raw_markets.append({
            "name": name,
            "distance_km": distance,
            "lat": round(geo["lat"] + lat_offset, 5),
            "lon": round(geo["lon"] + lon_offset, 5),
        })
    # Sort by distance so index 0 is always the closest
    raw_markets.sort(key=lambda m: m["distance_km"])
    return {
        "location": location,
        "farm_lat": geo["lat"],
        "farm_lon": geo["lon"],
        "geocode_source": geo["source"],
        "markets": raw_markets,
    }


# ----------------------------------------------------------------------
# Prices
# ----------------------------------------------------------------------
def get_real_market_prices(crop: str, state: str = None):
    if not REQUESTS_AVAILABLE:
        return None
    try:
        params = {
            "api-key": DATA_GOV_IN_API_KEY or "579b464db66ec23bdd000001cdd3946e44ce6c1d6907f5c7be62a51",
            "format": "json",
            "limit": 20,
            "filters[commodity]": crop.title(),
        }
        if state:
            params["filters[state]"] = state.title()
        resp = requests.get(
            f"https://api.data.gov.in/resource/{AGMARKNET_RESOURCE_ID}",
            params=params, timeout=8,
        )
        data = resp.json()
        records = data.get("records", [])
        if not records:
            return None
        return {
            "source": "data.gov.in (Agmarknet Variety-wise Daily Market Prices)",
            "records": [
                {
                    "market": r.get("market"),
                    "state": r.get("state"),
                    "modal_price_rs_per_quintal": r.get("modal_price"),
                    "date": r.get("price_date") or r.get("arrival_date"),
                }
                for r in records
            ],
        }
    except Exception:
        return None


def get_market_prices(crop: str, markets: list):
    crop = crop.strip().lower()
    profile = get_crop_profile(crop)
    base_rng = _seeded_rng(crop, "base")
    base_price = round(base_rng.uniform(8, 60), 2)
    today_ordinal = date.today().toordinal()
    results = {}
    for m in markets:
        m_rng = _seeded_rng(crop, m)
        market_offset = m_rng.uniform(-0.15, 0.20)
        seasonal = 0.05 * math.sin(today_ordinal / 17 + hash(m) % 7)
        current_price = max(1.0, base_price * (1 + market_offset + seasonal))
        trend_pct_per_day = m_rng.uniform(-profile["price_volatility_pct"], profile["price_volatility_pct"]) / 2
        results[m] = {
            "current_price_rs_per_kg": round(current_price, 2),
            "expected_trend_pct_per_day": round(trend_pct_per_day, 2),
            "volatility_pct_per_day": profile["price_volatility_pct"],
            "source": "mock_seeded_model",
        }
    return results


def estimate_transport_cost(distance_km: float, quantity_kg: float, vehicle_type: str = "mini_truck",
                             weather_delay_risk: float = 0.0):
    vehicle_rates = {
        "two_wheeler_cart": {"base_fare": 50, "per_km": 4, "per_kg": 0.0, "max_kg": 150},
        "mini_truck": {"base_fare": 300, "per_km": 12, "per_kg": 0.15, "max_kg": 1500},
        "truck": {"base_fare": 800, "per_km": 22, "per_kg": 0.08, "max_kg": 8000},
    }
    v = vehicle_rates.get(vehicle_type, vehicle_rates["mini_truck"])
    trips = math.ceil(quantity_kg / v["max_kg"]) if quantity_kg > v["max_kg"] else 1
    base_cost = trips * (v["base_fare"] + v["per_km"] * distance_km) + v["per_kg"] * quantity_kg
    weather_surcharge = base_cost * 0.25 * weather_delay_risk
    cost = base_cost + weather_surcharge
    return {
        "vehicle_type": vehicle_type,
        "trips_required": trips,
        "total_cost_rs": round(cost, 2),
        "cost_per_kg_rs": round(cost / quantity_kg, 3) if quantity_kg else 0,
        "weather_surcharge_rs": round(weather_surcharge, 2),
    }


def estimate_spoilage_loss(crop: str, storage_days: float, storage_type: str = "ambient",
                            weather_spoilage_multiplier: float = 1.0):
    profile = get_crop_profile(crop)
    daily_decay = profile["decay_rate_pct_per_day"] / 100.0
    multiplier = {"ambient": 1.0, "shaded": 0.7, "cold_storage": 0.15}.get(storage_type, 1.0)
    effective_daily_decay = min(daily_decay * multiplier * weather_spoilage_multiplier, 0.6)
    surviving_fraction = (1 - effective_daily_decay) ** max(storage_days, 0)
    loss_fraction = min(0.95, 1 - surviving_fraction)
    return {
        "storage_type": storage_type,
        "storage_days": storage_days,
        "weather_spoilage_multiplier": weather_spoilage_multiplier,
        "estimated_loss_fraction": round(loss_fraction, 4),
        "estimated_loss_pct": round(loss_fraction * 100, 2),
    }


def get_storage_cost(crop: str, quantity_kg: float, storage_days: float, storage_type: str = "ambient"):
    rate_per_kg_per_day = {"ambient": 0.0, "shaded": 0.05, "cold_storage": 0.45}.get(storage_type, 0.0)
    cost = rate_per_kg_per_day * quantity_kg * storage_days
    return {"storage_type": storage_type, "total_storage_cost_rs": round(cost, 2)}


def get_demand_index(crop: str, market: str, weather_demand_multiplier: float = 1.0):
    rng = _seeded_rng(crop, market, "demand")
    base = rng.uniform(0.2, 0.95)
    return {"market": market, "demand_index": round(min(1.0, base * weather_demand_multiplier), 3)}


# ----------------------------------------------------------------------
# RAG knowledge base
# ----------------------------------------------------------------------
_KB_PATH = os.path.join(DATA_DIR, "knowledge_base.json")
_KB_DOCS = None
_KB_VECTORIZER = None
_KB_MATRIX = None


def _load_knowledge_base():
    global _KB_DOCS, _KB_VECTORIZER, _KB_MATRIX
    if _KB_DOCS is not None:
        return
    with open(_KB_PATH) as f:
        _KB_DOCS = json.load(f)
    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        corpus = [d["text"] for d in _KB_DOCS]
        _KB_VECTORIZER = TfidfVectorizer(stop_words="english")
        _KB_MATRIX = _KB_VECTORIZER.fit_transform(corpus)
    except ImportError:
        _KB_VECTORIZER = None
        _KB_MATRIX = None


def search_knowledge_base(query: str, top_k: int = 3, category: str = None):
    _load_knowledge_base()
    docs = _KB_DOCS
    if category:
        docs = [d for d in docs if d.get("category") == category]
    if not docs:
        return {"results": []}
    if _KB_VECTORIZER is not None:
        from sklearn.feature_extraction.text import TfidfVectorizer
        sub_vectorizer = TfidfVectorizer(stop_words="english")
        sub_matrix = sub_vectorizer.fit_transform([d["text"] for d in docs])
        query_vec = sub_vectorizer.transform([query])
        scores = (sub_matrix @ query_vec.T).toarray().ravel()
    else:
        q_words = set(query.lower().split())
        scores = [float(len(q_words & set(d["text"].lower().split()))) for d in docs]
    ranked = sorted(zip(docs, scores), key=lambda x: x[1], reverse=True)
    results = []
    for doc, score in ranked[:top_k]:
        if score <= 0:
            continue
        results.append({
            "id": doc["id"],
            "category": doc.get("category"),
            "topic": doc.get("crop") or doc.get("term") or doc.get("id"),
            "text": doc["text"],
            "relevance_score": round(float(score), 3),
        })
    return {"results": results, "source": "local_rag_tfidf" if _KB_VECTORIZER else "local_rag_keyword_fallback"}


# ----------------------------------------------------------------------
# Monte Carlo — each trial independently samples price, spoilage, demand
# (fixes the original bug where price was held constant across trials)
# ----------------------------------------------------------------------
def _simulate_revenue_distribution(
    crop, quantity_kg, distance_km, days_to_sell, market, storage_type, vehicle_type, n_sims,
    weather=None,
):
    weather = weather or {}
    spoilage_mult_base = weather.get("spoilage_multiplier", 1.0)
    delay_risk = weather.get("transport_delay_risk", 0.0)
    demand_mult_base = weather.get("demand_multiplier", 1.0)

    price_info = get_market_prices(crop, [market])[market]
    p0 = price_info["current_price_rs_per_kg"]
    drift = price_info["expected_trend_pct_per_day"] / 100.0
    vol = price_info["volatility_pct_per_day"] / 100.0

    # Static costs computed once (transport and base storage are deterministic)
    transport = estimate_transport_cost(distance_km, quantity_kg, vehicle_type, weather_delay_risk=delay_risk)
    storage = get_storage_cost(crop, quantity_kg, days_to_sell, storage_type)
    spoil_expected = estimate_spoilage_loss(crop, days_to_sell, storage_type, weather_spoilage_multiplier=spoilage_mult_base)

    rng = random.Random(_seeded_rng(crop, market, days_to_sell, storage_type).randint(0, 10**9))
    revenues = []
    n_days = max(1, int(round(days_to_sell))) if days_to_sell > 0 else 0

    for _ in range(n_sims):
        # --- per-trial price path ---
        price_t = p0
        for _d in range(n_days):
            shock = rng.gauss(drift, vol)
            price_t = max(0.5, price_t * (1 + shock))

        # --- per-trial spoilage (weather uncertainty sampled each trial) ---
        spoilage_mult_trial = max(0.5, rng.gauss(spoilage_mult_base, 0.08))
        spoil_frac = estimate_spoilage_loss(
            crop, days_to_sell, storage_type,
            weather_spoilage_multiplier=spoilage_mult_trial
        )["estimated_loss_fraction"]
        loss_frac = min(0.97, max(0.0, rng.gauss(spoil_frac, 0.02)))
        sellable_kg = quantity_kg * (1 - loss_frac)

        # --- per-trial demand shock ---
        demand_mult_trial = max(0.5, min(1.2, rng.gauss(demand_mult_base, 0.05)))
        effective_price = price_t * demand_mult_trial

        revenue = sellable_kg * effective_price
        cost = transport["total_cost_rs"] + storage["total_storage_cost_rs"]
        revenues.append(revenue - cost)

    return revenues, transport, storage, spoil_expected, p0


def monte_carlo_revenue(
    crop: str,
    quantity_kg: float,
    distance_km: float,
    days_to_sell: float,
    market: str,
    storage_type: str = "ambient",
    vehicle_type: str = "mini_truck",
    n_sims: int = 3000,
    risk_aversion_lambda: float = 0.6,
    weather: dict = None,
):
    revenues, transport, storage, spoil, p0 = _simulate_revenue_distribution(
        crop, quantity_kg, distance_km, days_to_sell, market, storage_type, vehicle_type, n_sims,
        weather=weather,
    )
    mean_revenue = statistics.fmean(revenues)
    std_revenue = statistics.pstdev(revenues)
    variance = std_revenue ** 2
    revenues_sorted = sorted(revenues)
    var_idx = max(0, int(0.05 * len(revenues_sorted)) - 1)
    var_95 = revenues_sorted[var_idx]
    worst_5pct = revenues_sorted[: max(1, var_idx + 1)]
    cvar_95 = statistics.fmean(worst_5pct)
    certainty_equivalent = mean_revenue - 0.5 * risk_aversion_lambda * (variance / max(quantity_kg, 1))
    probability_of_loss = sum(1 for p in revenues if p < 0) / len(revenues)
    if probability_of_loss > 0.1 or std_revenue > abs(mean_revenue) * 0.5:
        risk_score_label = "High"
    elif probability_of_loss > 0.02 or std_revenue > abs(mean_revenue) * 0.25:
        risk_score_label = "Medium"
    else:
        risk_score_label = "Low"
    return {
        "market": market,
        "sell_day": days_to_sell,
        "storage_type": storage_type,
        "expected_revenue_rs": round(mean_revenue, 2),
        "revenue_std_dev_rs": round(std_revenue, 2),
        "var_95_rs": round(var_95, 2),
        "cvar_95_rs": round(cvar_95, 2),
        "certainty_equivalent_revenue_rs": round(certainty_equivalent, 2),
        "probability_of_loss": round(probability_of_loss, 4),
        "risk_score_label": risk_score_label,
        "risk_adjusted_score": round(certainty_equivalent, 2),
        "expected_spoilage_loss_pct": spoil["estimated_loss_pct"],
        "transport_cost_rs": transport["total_cost_rs"],
        "transport_cost_per_kg_rs": round(transport["total_cost_rs"] / max(quantity_kg, 1), 3),
        "storage_cost_rs": storage["total_storage_cost_rs"],
        "starting_price_rs_per_kg": p0,
        "weather_applied": weather is not None,
    }


def evaluate_all_strategies(
    crop: str,
    quantity_kg: float,
    markets: list,
    max_days: int = 6,
    storage_types: list = None,
    vehicle_type: str = "mini_truck",
    risk_aversion_lambda: float = 0.6,
    n_sims: int = 1500,
    top_n: int = 8,
    use_weather: bool = True,
):
    """
    Scans every (market x sell-day x storage-type) combination and returns
    results ranked by certainty-equivalent revenue, best first.
    markets must be a list of dicts with at least {name, distance_km}; lat/lon
    are optional but enable weather-adjusted risk.
    Normalises incoming market dicts defensively so LLM field-name drift
    doesn't break the simulation.
    """
    storage_types = storage_types or ["ambient"]

    # --- Normalise market dicts: accept name/market_name, distance_km/distance ---
    clean_markets = []
    for m in markets:
        if not isinstance(m, dict):
            continue
        name = m.get("name") or m.get("market_name") or m.get("market") or "Unknown Market"
        dist = float(m.get("distance_km") or m.get("distance") or 20)
        entry = {"name": str(name), "distance_km": dist}
        for coord in ("lat", "lon"):
            if coord in m:
                try:
                    entry[coord] = float(m[coord])
                except (TypeError, ValueError):
                    pass
        clean_markets.append(entry)

    if not clean_markets:
        return {"error": "No valid markets provided", "ranked_strategies": [], "total_strategies_evaluated": 0}

    rows = []
    weather_by_market = {}

    for m in clean_markets:
        name = m["name"]
        distance_km = m["distance_km"]
        weather = None
        if use_weather and "lat" in m and "lon" in m:
            weather = get_weather_risk(m["lat"], m["lon"])
            weather_by_market[name] = weather
        for sell_day in range(0, max_days + 1):
            for storage_type in storage_types:
                if sell_day == 0 and storage_type != storage_types[0]:
                    continue
                result = monte_carlo_revenue(
                    crop=crop,
                    quantity_kg=quantity_kg,
                    distance_km=distance_km,
                    days_to_sell=sell_day,
                    market=name,
                    storage_type=storage_type,
                    vehicle_type=vehicle_type,
                    n_sims=n_sims,
                    risk_aversion_lambda=risk_aversion_lambda,
                    weather=weather,
                )
                rows.append(result)

    rows.sort(key=lambda r: r["risk_adjusted_score"], reverse=True)
    for i, r in enumerate(rows):
        r["final_ranking"] = i + 1

    best = rows[0] if rows else None
    factor_table = None
    if best:
        factor_table = {
            "market_price_rs_per_kg": best["starting_price_rs_per_kg"],
            "transport_cost_rs_per_kg": best["transport_cost_per_kg_rs"],
            "expected_spoilage_pct": best["expected_spoilage_loss_pct"],
            "risk_score": best["risk_score_label"],
            "final_ranking": best["final_ranking"],
            "weather_risk": weather_by_market.get(best["market"], {}).get("weather_risk_label", "n/a"),
        }

    runner_up = rows[1] if len(rows) > 1 else None

    return {
        "best_strategy": best,
        "runner_up_strategy": runner_up,
        "factor_table": factor_table,
        "weather_by_market": weather_by_market,
        "ranked_strategies": rows[:top_n],
        "total_strategies_evaluated": len(rows),
    }


# ----------------------------------------------------------------------
# Multi-market split analysis
# When the farmer asks to sell across N specific markets, we evaluate
# the best (day, storage) for each market independently and combine.
# ----------------------------------------------------------------------
def evaluate_split_strategy(
    crop: str,
    total_quantity_kg: float,
    target_markets: list,          # [{name, distance_km, lat?, lon?, quantity_kg?}]
    max_days: int = 6,
    storage_types: list = None,
    vehicle_type: str = "mini_truck",
    risk_aversion_lambda: float = 0.6,
    n_sims: int = 1500,
):
    """
    Evaluates selling across multiple specific markets simultaneously.
    For each target market, finds the best (day, storage) independently,
    then aggregates total revenue, CVaR, and P(loss) across all legs.

    target_markets: list of market dicts. If quantity_kg is provided per
    market, use that split; otherwise split evenly.
    """
    storage_types = storage_types or ["ambient"]
    n = len(target_markets)
    if n == 0:
        return {"error": "No markets provided"}

    # Normalise and assign quantities
    clean = []
    total_explicit_qty = sum(float(m.get("quantity_kg") or 0) for m in target_markets)
    remainder = total_quantity_kg - total_explicit_qty
    unassigned = sum(1 for m in target_markets if not m.get("quantity_kg"))

    for m in target_markets:
        qty = float(m.get("quantity_kg") or 0)
        if qty == 0 and unassigned > 0:
            qty = remainder / unassigned
        name = m.get("name") or m.get("market_name") or m.get("market") or "Market"
        dist = float(m.get("distance_km") or m.get("distance") or 20)
        entry = {"name": str(name), "distance_km": dist, "quantity_kg": round(qty, 1)}
        for coord in ("lat", "lon"):
            if coord in m:
                try:
                    entry[coord] = float(m[coord])
                except (TypeError, ValueError):
                    pass
        clean.append(entry)

    # For each market, find its personal best (day, storage) combination
    legs = []
    for m in clean:
        best_leg = None
        weather = None
        if "lat" in m and "lon" in m:
            weather = get_weather_risk(m["lat"], m["lon"])
        for sell_day in range(0, max_days + 1):
            for storage_type in storage_types:
                if sell_day == 0 and storage_type != storage_types[0]:
                    continue
                result = monte_carlo_revenue(
                    crop=crop,
                    quantity_kg=m["quantity_kg"],
                    distance_km=m["distance_km"],
                    days_to_sell=sell_day,
                    market=m["name"],
                    storage_type=storage_type,
                    vehicle_type=vehicle_type,
                    n_sims=n_sims,
                    risk_aversion_lambda=risk_aversion_lambda,
                    weather=weather,
                )
                if best_leg is None or result["risk_adjusted_score"] > best_leg["risk_adjusted_score"]:
                    best_leg = result
        if best_leg:
            best_leg["allocated_quantity_kg"] = m["quantity_kg"]
            best_leg["weather_risk"] = (weather or {}).get("weather_risk_label", "n/a")
            legs.append(best_leg)

    if not legs:
        return {"error": "No legs could be evaluated"}

    total_expected = sum(l["expected_revenue_rs"] for l in legs)
    total_ce = sum(l["certainty_equivalent_revenue_rs"] for l in legs)
    total_cvar = sum(l["cvar_95_rs"] for l in legs)
    avg_prob_loss = statistics.fmean([l["probability_of_loss"] for l in legs])
    overall_risk = "High" if avg_prob_loss > 0.1 else ("Medium" if avg_prob_loss > 0.02 else "Low")

    return {
        "mode": "split",
        "total_quantity_kg": total_quantity_kg,
        "num_markets": len(legs),
        "legs": legs,
        "combined_expected_revenue_rs": round(total_expected, 2),
        "combined_ce_revenue_rs": round(total_ce, 2),
        "combined_cvar_95_rs": round(total_cvar, 2),
        "avg_probability_of_loss": round(avg_prob_loss, 4),
        "overall_risk_label": overall_risk,
    }


def build_recommendation_card(
    evaluation: dict,
    why: str = None,
    tip: dict = None,
    agents_consulted: str = "Market Research Agent, Risk Analyst Agent",
    data_sources: str = None,
) -> dict:
    """
    Builds the dashboard card DETERMINISTICALLY from evaluate_all_strategies
    or evaluate_split_strategy output. Handles both single-best and
    multi-market split results.
    """
    # ---- SPLIT mode ----
    if evaluation.get("mode") == "split":
        legs = evaluation.get("legs", [])
        practical_tip = None
        if tip and isinstance(tip, dict):
            hits = tip.get("results") or []
            if hits:
                practical_tip = hits[0].get("text")

        leg_rows = []
        for l in legs:
            leg_rows.append({
                "market": l["market"],
                "sell_day": int(l["sell_day"]),
                "storage": l["storage_type"],
                "qty_kg": l.get("allocated_quantity_kg"),
                "expected_revenue": f"Rs {l['expected_revenue_rs']}",
                "ce_revenue": f"Rs {l['certainty_equivalent_revenue_rs']}",
                "cvar": f"Rs {l['cvar_95_rs']}",
                "prob_loss": f"{round(l['probability_of_loss'] * 100, 1)}%",
                "weather_risk": l.get("weather_risk", "n/a"),
                "risk_score": l["risk_score_label"],
                "transport_cost": f"Rs {l['transport_cost_rs']}",
                "spoilage_pct": f"{l['expected_spoilage_loss_pct']}%",
            })

        return {
            "mode": "split",
            "recommendation": f"Sell across {len(legs)} markets simultaneously",
            "why": why or "",
            "expected_revenue": f"Rs {evaluation['combined_expected_revenue_rs']}",
            "ce_revenue": f"Rs {evaluation['combined_ce_revenue_rs']}",
            "cvar": f"Rs {evaluation['combined_cvar_95_rs']}",
            "prob_loss": f"{round(evaluation['avg_probability_of_loss'] * 100, 1)}%",
            "overall_risk": evaluation["overall_risk_label"],
            "legs": leg_rows,
            "practical_tip": practical_tip,
            "agents_consulted": agents_consulted,
            "data_sources": data_sources or "Market locations: OpenStreetMap. Weather: Open-Meteo. Prices: estimated model.",
            "raw": json.dumps(evaluation, indent=2, default=str),
        }

    # ---- SINGLE best mode ----
    best = evaluation.get("best_strategy")
    if not best:
        return None
    runner_up = evaluation.get("runner_up_strategy")
    factor_table = evaluation.get("factor_table") or {}
    ranked = evaluation.get("ranked_strategies") or []

    practical_tip = None
    if tip and isinstance(tip, dict):
        hits = tip.get("results") or []
        if hits:
            practical_tip = hits[0].get("text")

    factors = [
        {"factor": "Market Price", "value": f"Rs {factor_table.get('market_price_rs_per_kg')}/kg"},
        {"factor": "Transport Cost", "value": f"Rs {factor_table.get('transport_cost_rs_per_kg')}/kg"},
        {"factor": "Expected Spoilage", "value": f"{factor_table.get('expected_spoilage_pct')}%"},
        {"factor": "Weather Risk", "value": str(factor_table.get("weather_risk"))},
        {"factor": "Risk Score", "value": str(factor_table.get("risk_score"))},
        {"factor": "Final Ranking", "value": f"#{factor_table.get('final_ranking')}"},
    ]
    alternatives = [
        {
            "label": f"{row['market']} day{int(row['sell_day'])} {row['storage_type']}",
            "market": row["market"],
            "sell_day": int(row["sell_day"]),
            "storage_type": row["storage_type"],
            "ce": str(row["certainty_equivalent_revenue_rs"]),
            "mean": str(row["expected_revenue_rs"]),
            "cvar": str(row["cvar_95_rs"]),
            "prob_loss": f"{round(row['probability_of_loss'] * 100, 1)}%",
            "risk_score": row["risk_score_label"],
            "trend_pct": row.get("expected_trend_pct_per_day", 0),
        }
        for row in ranked[1:8]
    ]

    # ---- ranked_strategies_full: all rows grouped by market for sparklines / day-timeline ----
    ranked_full = [
        {
            "market": row["market"],
            "sell_day": int(row["sell_day"]),
            "storage_type": row["storage_type"],
            "ce": row["certainty_equivalent_revenue_rs"],
            "mean": row["expected_revenue_rs"],
            "std": row["revenue_std_dev_rs"],
            "prob_loss": round(row["probability_of_loss"] * 100, 1),
            "cvar": row["cvar_95_rs"],
            "risk_score": row["risk_score_label"],
            "transport_cost": row.get("transport_cost_rs", 0),
            "spoilage_pct": row.get("expected_spoilage_loss_pct", 0),
            "trend_pct": row.get("expected_trend_pct_per_day", 0),
        }
        for row in ranked
    ]

    # ---- confidence score: 1 - (std/mean), clamped 0-100 ----
    _std = best.get("revenue_std_dev_rs", 0)
    _mean = best.get("expected_revenue_rs", 1)
    confidence = max(0, min(100, round(100 * (1 - abs(_std) / max(abs(_mean), 1)), 0)))

    # ---- market_summary: best strategy per unique market ----
    seen_markets = {}
    for row in ranked:
        m = row["market"]
        if m not in seen_markets:
            seen_markets[m] = row
    market_summary = [
        {
            "market": m,
            "best_ce": r["certainty_equivalent_revenue_rs"],
            "best_mean": r["expected_revenue_rs"],
            "best_day": int(r["sell_day"]),
            "best_storage": r["storage_type"],
            "prob_loss": round(r["probability_of_loss"] * 100, 1),
            "risk_score": r["risk_score_label"],
            "trend_pct": r.get("expected_trend_pct_per_day", 0),
            "transport_cost": r.get("transport_cost_rs", 0),
            "is_winner": m == best["market"],
        }
        for m, r in seen_markets.items()
    ]

    # ---- break-even price ----
    transport_cost = best.get("transport_cost_rs", 0)
    qty = best.get("quantity_kg", 1)
    break_even_price = round((transport_cost / max(qty, 1)), 2) if transport_cost else None

    # ---- crop profile for perishability badge ----
    crop_name = best.get("crop", "")
    crop_profile = get_crop_profile(crop_name) if crop_name else {}

    # ---- RAG tip results for citation panel ----
    tip_results = []
    if tip and isinstance(tip, dict):
        tip_results = tip.get("results") or []

    return {
        "mode": "single",
        "recommendation": f"{best['market']}, sell on day {int(best['sell_day'])}, using {best['storage_type']} storage",
        "why": why or "",
        "expected_revenue": f"Rs {best['expected_revenue_rs']}",
        "ce_revenue": f"Rs {best['certainty_equivalent_revenue_rs']}",
        "cvar": f"Rs {best['cvar_95_rs']}",
        "prob_loss": f"{round(best['probability_of_loss'] * 100, 1)}%",
        "prob_loss_raw": round(best["probability_of_loss"] * 100, 1),
        "risk_score_label": best["risk_score_label"],
        "revenue_std": best.get("revenue_std_dev_rs", 0),
        "var_95": best.get("var_95_rs", 0),
        "n_sims": 1500,
        "sell_day": int(best["sell_day"]),
        "storage_type": best["storage_type"],
        "market_name": best["market"],
        "trend_pct_per_day": best.get("expected_trend_pct_per_day", 0),
        "transport_cost_rs": best.get("transport_cost_rs", 0),
        "spoilage_pct": best.get("expected_spoilage_loss_pct", 0),
        "factors": factors,
        "practical_tip": practical_tip,
        "tip_results": tip_results,
        "alternatives": alternatives,
        "ranked_strategies_full": ranked_full,
        "market_summary": market_summary,
        "confidence": confidence,
        "break_even_price_rs_per_kg": break_even_price,
        "perishability_class": crop_profile.get("perishability_class", ""),
        "shelf_life_days": crop_profile.get("shelf_life_days", None),
        "agents_consulted": agents_consulted,
        "data_sources": data_sources or "Market locations: OpenStreetMap. Weather: Open-Meteo. Prices: estimated model.",
        "raw": json.dumps({"best_strategy": best, "runner_up_strategy": runner_up}, indent=2, default=str),
    }
