# AgriMax Pro — Multi-Agent + RAG Actuarial Decision Support

This is the upgraded, more technical version of AgriMax, built on a genuine
**multi-agent architecture** (not one agent with a long tool list) plus a
**RAG (Retrieval-Augmented Generation)** knowledge base, an enhanced live
map, and full "Revenue" terminology throughout.

**Runs on a NEW port (7000)** — separate from any earlier AgriMax version
you may still have running on port 5000, so both can run side by side.

## What's new here vs. the previous single-agent version

### 1. Multi-agent architecture (Supervisor + 2 sub-agents)
Three separate LLM reasoning loops, each with its own system prompt and its
own tool set:

- **Supervisor** (`FarmerAdvisorAgent` in `agent.py`) — the farmer-facing
  agent. It does NOT call market/risk tools directly. It has exactly two
  tools: `consult_market_researcher` and `consult_risk_analyst`. It also
  enforces the conversational guardrails: redirecting off-topic questions,
  and asking a clarifying question if crop/location is missing.
- **Market Research Agent** (`MarketResearchAgent`) — decides whether to
  geocode, check weather, and check real-vs-estimated prices. Returns both
  a narrative AND the raw structured data (markets with coordinates), so
  nothing has to be re-parsed from free text downstream.
- **Risk Analyst Agent** (`RiskAnalystAgent`) — runs the full Monte Carlo /
  certainty-equivalent revenue evaluation and retrieves one grounded tip
  from the knowledge base.

This means the Supervisor's own tool list is short and clean (2 tools), while
the real domain tools are scoped to the sub-agent that actually needs them —
a standard supervisor/sub-agent pattern, and each sub-agent does its own
independent LLM-driven tool selection, not just a renamed function call.

### 2. RAG knowledge base
`tools.search_knowledge_base()` retrieves the most relevant entries from a
curated knowledge base (`data/knowledge_base.json`) — crop-handling tips,
logistics/market-strategy tips, and an actuarial glossary — using TF-IDF
cosine similarity (scikit-learn), fully offline, no embedding API needed.
The Risk Analyst Agent calls this once per analysis to ground its answer in
a concrete, practical tip rather than only reporting numbers.

### 3. Revenue terminology (renamed from Profit)
Every monetary field is now named/labeled "Revenue" throughout
`tools.py`, `agent.py`, `app.py`, and the frontend (`expected_revenue_rs`,
`certainty_equivalent_revenue_rs`, "EXECUTIVE SUMMARY → Expected Revenue",
etc.). Note for your own clarity: the underlying calculation is still
price × quantity **minus transport and storage costs** — i.e. what the
farmer actually keeps. If asked, the framing is: "Revenue" here means the
farmer's final take-home amount, not gross sale value before costs.

### 4. Enhanced map
- Farm marker uses a distinct house icon; market markers are numbered and
  color-coded (green = closest, amber = mid-distance, red = farthest) as a
  quick visual proxy for travel cost/risk.
- Dashed route lines are drawn from the farm to every candidate market.
- A legend explains the color coding.
- Map data now comes directly from the Market Research Agent's actual tool
  call result (captured structurally), not a regex guess at the location
  mentioned in the farmer's message.

### 5. Real market price priority
Both the Supervisor's and Market Research Agent's system prompts now
explicitly instruct: always try `get_real_market_prices` (data.gov.in /
Agmarknet) first, and only fall back to the estimated model if no real
record is found for that crop/region — stated transparently either way in
the final "Data sources" line.

## Setup & run

```bash
pip install -r requirements.txt
python app.py
```

Open **http://127.0.0.1:7000**. Optionally set `DATA_GOV_IN_API_KEY` for
more reliable real price coverage.

## Architecture at a glance

```
Farmer message
      │
      ▼
 SUPERVISOR (FarmerAdvisorAgent)
  - off-topic guard / missing-info clarifying question
  - tools: consult_market_researcher, consult_risk_analyst
      │                              │
      ▼                              ▼
 MARKET RESEARCH AGENT          RISK ANALYST AGENT
  - find_nearby_markets          - evaluate_all_strategies
  - get_weather_risk               (Monte Carlo, CE/CVaR/VaR/P(loss))
  - get_real_market_prices       - search_knowledge_base (RAG)
  - get_market_prices (fallback)
      │                              │
      └──────────► Supervisor composes the final farmer-facing answer ◄──┘
```

## Honest notes
- This sandbox environment had no internet access during development, so
  the live Nominatim/Open-Meteo/data.gov.in calls and the LangChain/Groq
  calls themselves could not be executed here. Every underlying function
  was tested thoroughly via its mock-fallback path, and the multi-agent
  orchestration logic was verified structurally (stubbed LLM responses).
  Please flag the exact error message if anything fails when you run it
  with real internet access, and it'll get fixed immediately.

## v3.1 fixes (this update)

1. **Wrong day/market sometimes recommended** (e.g. "sell on day 1" shown
   even though day 0 had higher revenue). Root cause: `tools.py`'s ranking
   math was already correct and fully deterministic (verified directly --
   the top-ranked strategy never changes between runs for the same
   inputs). The bug was that the Supervisor *LLM* was trusted to read the
   large `evaluate_all_strategies` JSON result and retype the winning
   market/day/storage/revenue numbers into its own free-text answer -- and
   it would occasionally restate the wrong row. **Fix:** the dashboard
   `card` is now built deterministically in Python
   (`tools.build_recommendation_card`) straight from `best_strategy` /
   `runner_up_strategy`. The LLM is never asked to restate those numbers
   again -- it only contributes a short "why" sentence, so what's shown on
   screen can no longer drift from what was actually computed.

2. **"Ask AI" felt like a report dump, not a chat.** The Supervisor used
   to compose the *entire* RECOMMENDATION/FACTOR BREAKDOWN/ALTERNATIVES
   text block as its chat reply, which was then pasted into the chat
   bubble verbatim every turn. **Fix:** the Supervisor's prompt now asks
   for one short, warm, 3-5 sentence message (name the pick, one
   plain-language why, the revenue figure in passing, a pointer to the
   dashboard). The full numeric breakdown only appears in the Results
   dashboard card, built from the deterministic numbers above -- never
   duplicated into the chat.

Also tightened while in there: the Risk Analyst's internal note is now
explicitly scoped to a 1-3 sentence trade-off based on
`best_strategy`/`runner_up_strategy` only; `app.py`'s old regex-based
`parse_structured_reply` is removed since the card no longer depends on
parsing the LLM's prose at all -- one less place for drift to creep back
into later.
